## -----------------------------------------------------------------------------
#| label: preparation-m07
library(tidyverse)
library(slider)
library(forecast)

# Ouvrir le projet .Rproj fourni : R/ et data/ sont à côté du rapport.
source("R/fonctions-module07.R")
demande <- read_csv("data/demande_hebdomadaire_quebec.csv",
                    show_col_types = FALSE) |>
  mutate(semaine = as.Date(semaine)) |>
  arrange(semaine)
stopifnot(nrow(demande) == 104L, !anyNA(demande),
          !anyDuplicated(demande$semaine),
          all(diff(demande$semaine) == 7))
horizon <- 13L
apprentissage <- demande |> slice_head(n = 91)
validation <- demande |> slice_tail(n = horizon)
serie <- ts(apprentissage$demande, frequency = 52)


## -----------------------------------------------------------------------------
#| label: moyennes-mobiles-m07
#| fig-width: 9
#| fig-height: 4.3
lissage <- apprentissage |>
  mutate(mm4 = slide_dbl(demande, mean, .before = 3, .complete = TRUE),
         mm13 = slide_dbl(demande, mean, .before = 12, .complete = TRUE))
lissage |>
  select(semaine, demande, mm4, mm13) |>
  pivot_longer(-semaine, names_to = "serie", values_to = "unites") |>
  ggplot(aes(semaine, unites, colour = serie)) +
  geom_line(linewidth = 0.7, na.rm = TRUE) +
  labs(x = NULL, y = "Demande (unités par semaine)", colour = "Série") +
  theme_minimal(base_size = 12)
tail(lissage |> select(semaine, demande, mm4, mm13), 4)
mean(c(980, 1020, 1080, 1120))


## -----------------------------------------------------------------------------
#| label: alpha-m07
#| fig-width: 9
#| fig-height: 4.3
exemple <- tibble(observe = c(100, 100, 140, 140),
                  alpha_02 = niveau_ses(observe, 0.2),
                  alpha_08 = niveau_ses(observe, 0.8))
exemple
niveaux <- apprentissage |>
  mutate(alpha_02 = niveau_ses(demande, 0.2),
         alpha_08 = niveau_ses(demande, 0.8))
niveaux |>
  select(semaine, demande, alpha_02, alpha_08) |>
  pivot_longer(-semaine, names_to = "serie", values_to = "unites") |>
  ggplot(aes(semaine, unites, colour = serie)) +
  geom_line(linewidth = 0.7) +
  labs(x = NULL, y = "Demande (unités par semaine)", colour = "Série") +
  theme_minimal(base_size = 12)
modele_ses <- ses(serie, h = horizon, initial = "optimal")
modele_ses$model$par["alpha"]


## -----------------------------------------------------------------------------
#| label: previsions-m07
# Règles fixées avant de consulter les scores : origine unique, h = 1 à 13.
# MM4 : répéter la dernière moyenne observée, sans mise à jour future.
previsions <- tibble(
  semaine = validation$semaine,
  observe = validation$demande,
  Naive = rep(tail(apprentissage$demande, 1), horizon),
  MM4 = rep(mean(tail(apprentissage$demande, 4)), horizon),
  SES = as.numeric(modele_ses$mean),
  Saisonnier = as.numeric(snaive(serie, h = horizon)$mean)
)
erreurs <- previsions |>
  pivot_longer(Naive:Saisonnier, names_to = "methode", values_to = "prevision") |>
  mutate(erreur = observe - prevision)
scores <- erreurs |>
  group_by(methode) |>
  group_modify(~ mesures_erreurs(.x$observe, .x$prevision)) |>
  ungroup() |>
  arrange(MAE)
scores |> select(methode, ME, MAE, RMSE)

## -----------------------------------------------------------------------------
#| label: graphiques-m07
#| fig-width: 9
#| fig-height: 4.3
# Chaque observation est tracée une seule fois.
ggplot() +
  geom_line(data = validation, aes(semaine, demande), linewidth = 1) +
  geom_line(data = erreurs, aes(semaine, prevision, colour = methode),
            linewidth = 0.7) +
  labs(x = NULL, y = "Demande (unités par semaine)", colour = "Méthode") +
  theme_minimal(base_size = 12)
ggplot(erreurs, aes(semaine, erreur, colour = methode)) +
  geom_hline(yintercept = 0, colour = "grey55") +
  geom_line() + geom_point() +
  labs(x = NULL, y = "Observé − prévu (unités)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: cout-m07
# Sensibilité hypothétique : une unité sous-prévue coûte 2, une sur-prévue 1.
scores_cout <- erreurs |>
  group_by(methode) |>
  group_modify(~ mesures_erreurs(.x$observe, .x$prevision,
                                cout_sous = 2, cout_sur = 1)) |>
  ungroup() |>
  arrange(cout_moyen)
scores_cout |> select(methode, MAE, cout_moyen, sous_previsions)


## -----------------------------------------------------------------------------
#| label: holt-m07
# Facultatif : comparer une tendance amortie, sans composante saisonnière.
modele_holt <- holt(serie, h = horizon, damped = TRUE)
comparaison_holt <- bind_rows(
  scores |> select(methode, ME, MAE, RMSE),
  mesures_erreurs(validation$demande, as.numeric(modele_holt$mean)) |>
    mutate(methode = "Holt amorti") |> select(methode, ME, MAE, RMSE)
)
comparaison_holt |> arrange(MAE)

