p <- 0.20
cote <- p / (1 - p)
nouvelle_cote <- 2 * cote
nouvelle_probabilite <- nouvelle_cote / (1 + nouvelle_cote)
c(cote = cote, nouvelle_cote = nouvelle_cote, nouvelle_probabilite = nouvelle_probabilite)


library(tidyverse)

racines <- c(".", "modules/semaine-10-classification-modeles-avances")
racine <- racines[file.exists(file.path(racines, "data/fidelisation_clients_quebec.csv"))][1]
stopifnot(!is.na(racine))
clients <- read_csv(file.path(racine, "data/fidelisation_clients_quebec.csv"), show_col_types = FALSE) |>
  mutate(type_contrat = factor(type_contrat, levels = c("annuel", "mensuel")),
         rabais_actuel = factor(rabais_actuel, levels = c("aucun", "fidélité", "rétention")))
stopifnot(nrow(clients) == 650, !anyDuplicated(clients$client_id),
          !anyNA(clients), all(clients$depart_90j %in% c(0, 1)))
set.seed(210110)
clients <- clients |> group_by(depart_90j) |>
  mutate(tirage = sample.int(n()),
         partition = case_when(tirage <= floor(0.60 * n()) ~ "apprentissage",
                               tirage <= floor(0.80 * n()) ~ "validation",
                               TRUE ~ "test")) |> ungroup()
apprentissage <- clients |> filter(partition == "apprentissage")
validation <- clients |> filter(partition == "validation")
test <- clients |> filter(partition == "test")
stopifnot(length(intersect(apprentissage$client_id, validation$client_id)) == 0,
          length(intersect(apprentissage$client_id, test$client_id)) == 0,
          length(intersect(validation$client_id, test$client_id)) == 0)
clients |> count(partition, depart_90j)


modele <- glm(depart_90j ~ anciennete_mois + utilisation_mensuelle + tickets_service_6m +
                satisfaction + type_contrat + rabais_actuel,
              data = apprentissage, family = binomial())
stopifnot(modele$converged, all(is.finite(coef(modele))))
exp(coef(modele))
profils <- tibble(anciennete_mois = c(24, 24), utilisation_mensuelle = c(12, 12),
                  tickets_service_6m = c(1, 3), satisfaction = c(7, 7),
                  type_contrat = factor(c("mensuel", "mensuel"), levels = levels(clients$type_contrat)),
                  rabais_actuel = factor(c("aucun", "aucun"), levels = levels(clients$rabais_actuel)))
profils |> mutate(probabilite = predict(modele, newdata = profils, type = "response")) |>
  select(tickets_service_6m, probabilite)


resume <- summary(modele)$coefficients
resume
# Intervalle de Wald pour les log-cotes, puis transformation en rapport de cotes.
estimation <- coef(modele)
erreur_type <- sqrt(diag(vcov(modele)))
tibble(terme = names(estimation), rapport_cotes = exp(estimation),
       borne_basse = exp(estimation - 1.96 * erreur_type),
       borne_haute = exp(estimation + 1.96 * erreur_type))
modele_nul <- glm(depart_90j ~ 1, data = apprentissage, family = binomial())
anova(modele_nul, modele, test = "Chisq")


mesures_seuil <- function(observe, probabilite, seuil, cout_fp = 1, cout_fn = 4) {
  stopifnot(length(observe) == length(probabilite), all(observe %in% c(0, 1)),
            all(is.finite(probabilite)), all(probabilite >= 0 & probabilite <= 1))
  predit <- as.integer(probabilite >= seuil)
  vp <- sum(predit == 1 & observe == 1); fp <- sum(predit == 1 & observe == 0)
  vn <- sum(predit == 0 & observe == 0); fn <- sum(predit == 0 & observe == 1)
  ratio <- function(a, b) if (b == 0) NA_real_ else a / b
  tibble(seuil, VP = vp, FP = fp, VN = vn, FN = fn,
         exactitude = ratio(vp + vn, length(observe)), sensibilite = ratio(vp, vp + fn),
         specificite = ratio(vn, vn + fp), precision = ratio(vp, vp + fp),
         proportion_ciblee = ratio(vp + fp, length(observe)), cout = cout_fp * fp + cout_fn * fn)
}


validation <- validation |> mutate(probabilite = predict(modele, newdata = validation, type = "response"))
resultats_validation <- bind_rows(mesures_seuil(validation$depart_90j, validation$probabilite, 0.30),
                                 mesures_seuil(validation$depart_90j, validation$probabilite, 0.50))
resultats_validation |> select(seuil, VP, FP, VN, FN, cout)
resultats_validation |> select(seuil, sensibilite, specificite, precision, proportion_ciblee)
seuil_retenu <- resultats_validation |> arrange(cout, seuil) |> slice(1) |> pull(seuil)
seuil_retenu


positifs <- validation$probabilite[validation$depart_90j == 1]
negatifs <- validation$probabilite[validation$depart_90j == 0]
auc <- mean(outer(positifs, negatifs, ">")) + 0.5 * mean(outer(positifs, negatifs, "=="))
auc
seuils <- seq(0, 1, by = 0.02)
roc <- map_dfr(seuils, ~ mesures_seuil(validation$depart_90j, validation$probabilite, .x)) |>
  mutate(taux_faux_positifs = 1 - specificite)
ggplot(roc, aes(taux_faux_positifs, sensibilite)) + geom_path() +
  geom_abline(linetype = 2) + coord_equal() +
  labs(x = "Taux de faux positifs", y = "Sensibilité") + theme_minimal()


library(rpart)
arbre <- rpart(factor(depart_90j, levels = c(0, 1)) ~ anciennete_mois + utilisation_mensuelle +
                 tickets_service_6m + satisfaction + type_contrat + rabais_actuel,
               data = apprentissage, method = "class", control = rpart.control(cp = 0.02))
prob_arbre <- predict(arbre, newdata = validation, type = "prob")[, "1"]
evaluation_arbre <- mesures_seuil(validation$depart_90j, prob_arbre, 0.30)
evaluation_arbre |> select(seuil, VP, FP, VN, FN, cout)
evaluation_arbre |> select(sensibilite, specificite, precision, proportion_ciblee)
plot(arbre, uniform = TRUE); text(arbre, use.n = TRUE, cex = 0.8)


service_temps <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |> arrange(succursale, date) |>
  group_by(succursale) |>
  mutate(ruptures_retard_1 = lag(ruptures_stock),
         etiquette_precedente = lag(service_insuffisant_mois_suivant),
         sinus_mois = sin(2 * pi * lubridate::month(date) / 12),
         cosinus_mois = cos(2 * pi * lubridate::month(date) / 12)) |> ungroup()
ancien <- service_temps |> filter(date <= as.Date("2023-11-01"), !is.na(ruptures_retard_1))
validation_temps <- service_temps |> filter(date >= as.Date("2024-01-01"), date <= as.Date("2024-11-01"))
modele_temps <- glm(service_insuffisant_mois_suivant ~ ruptures_retard_1 + sinus_mois + cosinus_mois,
                    data = ancien, family = binomial())
prob_temps <- predict(modele_temps, newdata = validation_temps, type = "response")
mesures_temps <- mesures_seuil(validation_temps$service_insuffisant_mois_suivant, prob_temps, 0.30)
mesures_temps |> select(seuil, VP, FP, VN, FN, cout)
mesures_temps |> select(sensibilite, specificite, precision, proportion_ciblee)
# Référence naïve : réutiliser l’étiquette du mois précédent si elle est connue.
stopifnot(!anyNA(validation_temps$etiquette_precedente))
naive_temps <- mesures_seuil(validation_temps$service_insuffisant_mois_suivant,
                             validation_temps$etiquette_precedente, 0.5)
naive_temps |> select(VP, FP, VN, FN, cout)


library(nnet)
variables <- c("anciennete_mois", "utilisation_mensuelle", "tickets_service_6m", "satisfaction")
x_a <- as.matrix(apprentissage[, variables]); x_v <- as.matrix(validation[, variables])
centres <- colMeans(x_a); ecarts <- apply(x_a, 2, sd)
stopifnot(all(ecarts > 0))
x_a <- scale(x_a, center = centres, scale = ecarts)
x_v <- scale(x_v, center = centres, scale = ecarts)
set.seed(210110)
reseau <- nnet(x_a, apprentissage$depart_90j, size = 3, entropy = TRUE,
               decay = 0.1, maxit = 500, trace = FALSE)
reseau$convergence
prob_reseau <- as.numeric(predict(reseau, x_v, type = "raw"))
mesures_reseau <- mesures_seuil(validation$depart_90j, prob_reseau, 0.30)
mesures_reseau |> select(seuil, VP, FP, VN, FN, cout)
mesures_reseau |> select(sensibilite, specificite, precision, proportion_ciblee)


library(forecast)
ventes_mensuelles <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |> group_by(date) |>
  summarise(ventes = sum(ventes), .groups = "drop") |> arrange(date)
ventes_ts <- ts(ventes_mensuelles$ventes, start = c(2020, 1), frequency = 12)
serie_train <- window(ventes_ts, end = c(2023, 12))
serie_validation <- window(ventes_ts, start = c(2024, 1), end = c(2024, 12))
set.seed(210110)
reseau_ts <- nnetar(serie_train, p = 2, P = 1, size = 2, repeats = 3,
                    scale.inputs = TRUE, maxit = 2000)
vapply(reseau_ts$model, function(x) x$convergence, integer(1))
prevision_ts <- forecast(reseau_ts, h = 12)$mean
reference_ts <- snaive(serie_train, h = 12)$mean
tibble(methode = c("NNAR", "Naïf saisonnier"),
       MAE = c(mean(abs(serie_validation - prevision_ts)), mean(abs(serie_validation - reference_ts))),
       RMSE = c(sqrt(mean((serie_validation - prevision_ts)^2)), sqrt(mean((serie_validation - reference_ts)^2))))
