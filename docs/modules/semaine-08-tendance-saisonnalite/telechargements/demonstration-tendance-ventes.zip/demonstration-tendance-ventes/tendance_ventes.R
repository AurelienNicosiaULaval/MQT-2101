## -----------------------------------------------------------------------------
#| label: preparation-m08
library(tidyverse)
library(broom)
source("R/fonctions-module08.R")
ventes <- read_csv("data/ventes_saisonnieres_quebec.csv", show_col_types = FALSE) |>
  preparer_calendrier()
stopifnot(nrow(ventes) == 72L)
apprentissage <- ventes |> slice_head(n = 60)
validation <- ventes |> slice_tail(n = 12)
# Les prédicteurs futurs sont construits sans les ventes ni le budget de validation.
futur <- calendrier_futur("2025-01-01", horizon = 12, dernier_indice = 60)
serie <- ts(apprentissage$ventes, frequency = 12, start = c(2020, 1))


## -----------------------------------------------------------------------------
#| label: exploration-m08
#| fig-width: 9
#| fig-height: 4.3
ggplot(apprentissage, aes(date, ventes / 1000)) +
  geom_line(colour = "#0B4F6C") +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)") +
  theme_minimal(base_size = 12)
ggplot(apprentissage, aes(mois, ventes / 1000, group = factor(annee), colour = factor(annee))) +
  geom_line() + geom_point() +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)", colour = "Année") +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


## -----------------------------------------------------------------------------
#| label: calendrier-m08
# La cible, le calendrier et la séparation sont vérifiés avant l’ajustement.
apprentissage |> select(date, indice_temps, mois) |> slice(c(1, 2, 12, 13, 60))
modele_tendance <- lm(ventes ~ indice_temps, data = apprentissage)
modele_saison <- lm(ventes ~ mois, data = apprentissage,
                    contrasts = list(mois = "contr.treatment"))
modele_calendrier <- lm(ventes ~ indice_temps + mois, data = apprentissage,
                        contrasts = list(mois = "contr.treatment"))
modeles <- list(Tendance = modele_tendance, Saison = modele_saison,
                Calendrier = modele_calendrier)
model.matrix(modele_calendrier)[c(1, 2, 12), c(1, 2, 3, 13)]
tidy(modele_calendrier, conf.int = TRUE) |>
  filter(term %in% c("indice_temps", "moisdécembre"))


## -----------------------------------------------------------------------------
#| label: diagnostic-m08
#| fig-width: 9
#| fig-height: 4.2
diagnostic <- apprentissage |>
  mutate(ajuste = fitted(modele_calendrier), residu = residuals(modele_calendrier))
ggplot(diagnostic, aes(date, residu / 1000)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_line() +
  labs(x = NULL, y = "Résidu (milliers de $ CA)") + theme_minimal(base_size = 12)
ggplot(diagnostic, aes(ajuste / 1000, residu / 1000)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_point() +
  labs(x = "Valeur ajustée (milliers de $ CA)", y = "Résidu (milliers de $ CA)") +
  theme_minimal(base_size = 12)
# Comparer ce qui reste par mois avec et sans terme de calendrier.
residus_mensuels <- imap_dfr(modeles, function(modele, nom) {
  tibble(mois = apprentissage$mois, residu = residuals(modele), methode = nom)
}) |>
  group_by(methode, mois) |> summarise(residu_moyen = mean(residu), .groups = "drop")
residus_mensuels |>
  ggplot(aes(mois, residu_moyen / 1000, colour = methode, group = methode)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_line() + geom_point() +
  labs(x = NULL, y = "Résidu mensuel moyen (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


## -----------------------------------------------------------------------------
#| label: validation-m08
#| fig-width: 9
#| fig-height: 4.3
previsions <- imap_dfr(modeles, function(modele, nom) {
  tibble(date = futur$date, observe = validation$ventes, methode = nom,
         prevision = as.numeric(predict(modele, newdata = futur)))
}) |>
  bind_rows(tibble(date = futur$date, observe = validation$ventes,
                   methode = "Saisonnier_naif", prevision = tail(apprentissage$ventes, 12)))
scores <- previsions |> group_by(methode) |>
  group_modify(~ mesures08(.x$observe, .x$prevision)) |> ungroup() |> arrange(MAE)
scores
ggplot() +
  geom_line(data = validation, aes(date, ventes / 1000), linewidth = 1) +
  geom_line(data = previsions, aes(date, prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: incertitude-m08
#| fig-width: 9
#| fig-height: 4.5
ip <- predict(modele_calendrier, newdata = futur, interval = "prediction", level = 0.95)
ic <- predict(modele_calendrier, newdata = futur, interval = "confidence", level = 0.95)
previsions_intervalle <- futur |>
  select(date, indice_temps, mois) |>
  bind_cols(as_tibble(ip)) |>
  mutate(observe = validation$ventes, budget_cible = validation$budget_cible,
         ic_inf = ic[, "lwr"], ic_sup = ic[, "upr"],
         dans_intervalle = observe >= lwr & observe <= upr)
previsions_intervalle |> select(date, fit, lwr, upr, ic_inf, ic_sup) |> slice_head(n = 3)
ggplot(previsions_intervalle, aes(date)) +
  geom_ribbon(aes(ymin = lwr / 1000, ymax = upr / 1000), fill = "#BFDDE5", alpha = 0.6) +
  geom_line(aes(y = fit / 1000), colour = "#0B4F6C", linewidth = 0.8) +
  geom_point(aes(y = observe / 1000)) +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)",
       subtitle = "Intervalles de prédiction ponctuels à 95 %, sous les hypothèses du modèle") +
  theme_minimal(base_size = 12)
previsions_intervalle |>
  summarise(mois_dans_intervalle = sum(dans_intervalle),
            ecart_moyen_au_budget = mean(fit - budget_cible))

