# tendance-ventes

Module 08, automne 2026.
1. Décompressez toute l’archive et ouvrez le .Rproj.
2. Installez tidyverse et broom si nécessaire. R, RStudio et Quarto sont requis.
3. Pour lire la décomposition, ouvrez decomposition-guidee.qmd, installez forecast au besoin et cliquez sur Render.
4. Ouvrez le .qmd, redémarrez R, puis faites Render. Les projets de départ se rendent avant d’être complétés.
5. Ajoutez vos calculs et interprétations à chaque étape, une seule fois.
6. Conservez data/ et R/. Aucun objet créé seulement dans la console n’est requis.

Deux séries québécoises entièrement simulées. Chaque fichier décrit 72 mois, janvier 2020 à décembre 2025.
Les calculs apprennent sur 60 mois, puis comparent 12 mois. La validation sert au choix, sans test final indépendant.
Le rapport est un entraînement. Les compléments ne sont pas requis dans la trace principale.
Le budget cible n’est pas un prédicteur. Les prix et promotions futurs observés ne sont pas utilisés dans le socle.
Les exercices commerciaux accompagnés utilisent explicitement un contexte réalisé ou un scénario hypothétique.
Pour régénérer les deux CSV dans une copie: source('R/regenerer-donnees.R'). Ce script réécrit les fichiers locaux.
Les liens officiels des ouvrages sont des compléments en ligne; les calculs utilisent seulement les fichiers fournis.
Attribution: matériel du cours MQT-2101, Université Laval; données simulées redistribuables avec le cours.
Ancien notebook Amtrak consulté: Paolo Landa, 16 mars 2021. Les anciens documents protégés ne sont pas inclus.
