library(tidyverse)
library(lubridate)

racines <- c(".", "modules/atelier-04-recapitulation")
racine <- racines[file.exists(file.path(racines, "data/cas_integrateur_quebec.csv"))][1]
stopifnot(!is.na(racine))
cas <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date), succursale = factor(succursale),
         promotion = factor(promotion, levels = c("non", "oui")),
         mois = factor(month(date), levels = 1:12)) |> arrange(date, succursale)
stopifnot(nrow(cas) == 288, n_distinct(cas$succursale) == 4,
          !anyDuplicated(cas[c("date", "succursale")]), !anyNA(cas))
cas |> summarise(lignes = n(), debut = min(date), fin = max(date),
                  succursales = n_distinct(succursale), mois = n_distinct(date))


# Explorer uniquement la période qui précède la validation de 2025.
cas |> filter(date < as.Date("2025-01-01")) |>
  ggplot(aes(date, ventes, colour = succursale)) + geom_line() +
  facet_wrap(~ succursale, scales = "free_y") +
  labs(x = "Mois", y = "Ventes (dollars)", colour = NULL) +
  theme_minimal(base_size = 11) + theme(legend.position = "none")


apprentissage_a <- cas |> filter(date < as.Date("2025-01-01"))
validation_a <- cas |> filter(date >= as.Date("2025-01-01"))
modele_ventes <- lm(ventes ~ indice_temps + succursale + mois, data = apprentissage_a)
reference_a <- apprentissage_a |> filter(year(date) == 2024) |>
  transmute(date = date %m+% years(1), succursale, reference = ventes)
stopifnot(nrow(validation_a) == 48, nrow(reference_a) == 48)
comparaison_a <- validation_a |>
  mutate(regression = as.numeric(predict(modele_ventes, newdata = validation_a))) |>
  left_join(reference_a, by = c("date", "succursale")) |>
  pivot_longer(c(regression, reference), names_to = "methode", values_to = "prevision") |>
  mutate(erreur = ventes - prevision)
stopifnot(!anyNA(comparaison_a$prevision), nrow(comparaison_a) == 96)
scores_a <- comparaison_a |> group_by(methode) |>
  summarise(ME = mean(erreur), MAE = mean(abs(erreur)), RMSE = sqrt(mean(erreur^2)), .groups = "drop")
scores_a


comparaison_a |> group_by(succursale, methode) |>
  summarise(MAE = mean(abs(erreur)), .groups = "drop")
