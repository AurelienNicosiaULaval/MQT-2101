## -----------------------------------------------------------------------------
#| eval: false
# install.packages(c("tidyverse", "forecast"))


## -----------------------------------------------------------------------------
#| label: preparation-calculs-06
library(tidyverse)
library(forecast)

# Dans le projet téléchargé, R/ et data/ sont à côté du document.
chemins_R <- c("R/analyse-module06.R",
               "modules/semaine-06-series-chronologiques-intro/R/analyse-module06.R")
chemin_R <- chemins_R[file.exists(chemins_R)][1]
stopifnot(!is.na(chemin_R))
source(chemin_R)
chemins <- c("data/consommation_electrique_batiment_quebec.csv",
             "modules/semaine-06-series-chronologiques-intro/data/consommation_electrique_batiment_quebec.csv")
chemin <- chemins[file.exists(chemins)][1]
stopifnot(!is.na(chemin))
analyse <- charger_module06(chemin)
electricite <- analyse$electricite
apprentissage <- analyse$apprentissage
validation <- analyse$validation


## -----------------------------------------------------------------------------
glimpse(electricite)
electricite |>
  summarise(debut = min(date), fin = max(date), observations = n(),
            dates_dupliquees = sum(duplicated(date)),
            consommation_manquante = sum(is.na(consommation_kwh)))


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
graphique_serie(apprentissage)


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
ggplot(apprentissage, aes(mois, consommation_kwh / 1000,
                         group = annee, colour = factor(annee))) +
  geom_line() + geom_point() +
  scale_x_continuous(breaks = 1:12) +
  labs(x = "Mois", y = "Consommation (MWh)", colour = "Année") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
zoom <- apprentissage |> filter(date >= as.Date("2023-01-01"))
graphique_serie(zoom)


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
stopifnot(all(apprentissage$consommation_kwh > 0))
graphique_serie(apprentissage) + scale_y_log10()


## -----------------------------------------------------------------------------
serie <- ts(apprentissage$consommation_kwh, start = c(2020, 1), frequency = 12)
fenetre <- window(serie, start = c(2023, 1), end = c(2024, 12))
modele_tendance <- tslm(serie ~ trend + I(trend^2))


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
graphique_serie(apprentissage) +
  geom_line(aes(y = as.numeric(fitted(modele_tendance)) / 1000),
            colour = "#7A1C24", linewidth = 1)


## -----------------------------------------------------------------------------
dates_attendues <- seq.Date(min(apprentissage$date),
                           max(apprentissage$date), by = "month")
calendrier <- tibble(date = dates_attendues) |>
  left_join(apprentissage |> select(date, consommation_kwh), by = "date")
stopifnot(!anyDuplicated(apprentissage$date))
calendrier |> filter(is.na(consommation_kwh))


## -----------------------------------------------------------------------------
exemple_incomplet <- apprentissage |>
  filter(date != as.Date("2022-02-01")) |>
  mutate(consommation_kwh = if_else(date == as.Date("2022-03-01"), NA_real_, consommation_kwh))

# Rétablir la grille rend les deux problèmes visibles, sans imputer.
tibble(date = dates_attendues) |>
  left_join(exemple_incomplet |> select(date, consommation_kwh), by = "date") |>
  filter(is.na(consommation_kwh))


## -----------------------------------------------------------------------------
refs <- prevoir_references(apprentissage$consommation_kwh, horizon = 12, periode = 12)
prevision_tendance <- forecast(modele_tendance, h = 12)

previsions <- validation |>
  mutate(naive = refs$naive, saisonniere = refs$saisonniere,
         tendance = as.numeric(prevision_tendance$mean))
previsions |> select(date, consommation_kwh, naive, saisonniere, tendance) |> head()


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
graphique_validation(analyse)


## -----------------------------------------------------------------------------
# Les trois candidats utilisent le même dénominateur saisonnier pour la MASE.
analyse$comparaison |> knitr::kable(digits = 2,
  col.names = c("Méthode", "ME (kWh)", "MAE (kWh)", "RMSE (kWh)", "MAPE (%)", "MASE"),
  format.args = list(decimal.mark = ",", big.mark = " "))

# Illustration indépendante, avec erreurs -20 et +20.
mesures_erreur(observe = c(80, 120), prevision = c(100, 100),
               apprentissage = c(80, 90, 100), periode = 1)


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
erreurs <- analyse$evaluation |> filter(methode == "saisonniere")
ggplot(erreurs, aes(date, erreur / 1000)) +
  geom_hline(yintercept = 0, linetype = 2) +
  geom_line(colour = "#0B4F6C") + geom_point() +
  labs(x = NULL, y = "Erreur (MWh)") + theme_minimal()


## -----------------------------------------------------------------------------
#| fig-width: 8
#| fig-height: 4.5
ggplot(erreurs, aes(erreur / 1000)) +
  geom_histogram(bins = 6, fill = "#D9EEF2", colour = "#0B4F6C") +
  labs(x = "Erreur de prévision (MWh)", y = "Nombre de mois") +
  theme_minimal()


## -----------------------------------------------------------------------------
# Trois structures illustratives, toutes ajustées à la même origine.
modeles_ets <- list(
  ANN = ets(serie, model = "ANN"),
  AAN = ets(serie, model = "AAN"),
  AAA = ets(serie, model = "AAA")
)
cones <- map(modeles_ets, ~ forecast(.x, h = 12, level = c(80, 95)))


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
autoplot(cones$AAN) +
  labs(x = "Année", y = "Consommation (kWh)", title = "Exemple ETS(A,A,N)") +
  scale_y_continuous(labels = function(x) nombre_fr(x))


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
walk(names(cones), function(nom) {
  print(autoplot(cones[[nom]]) +
          labs(x = "Année", y = "Consommation (kWh)", title = paste("Exemple ETS", nom)) +
          scale_y_continuous(labels = function(x) nombre_fr(x)))
})


## -----------------------------------------------------------------------------
tibble(
  h = c(1L, 12L),
  point = as.numeric(cones$AAN$mean[c(1, 12)]),
  bas_80 = cones$AAN$lower[c(1, 12), "80%"],
  haut_80 = cones$AAN$upper[c(1, 12), "80%"],
  bas_95 = cones$AAN$lower[c(1, 12), "95%"],
  haut_95 = cones$AAN$upper[c(1, 12), "95%"]
) |> knitr::kable(digits = 0)


## -----------------------------------------------------------------------------
# Illustration avec une référence choisie; ce n'est pas un classement imposé.
serie_complete <- ts(electricite$consommation_kwh, start = c(2020, 1), frequency = 12)
prevision_2026 <- snaive(serie_complete, h = 12)
head(prevision_2026$mean)


## -----------------------------------------------------------------------------
mobile <- validation_mobile(electricite$consommation_kwh, debut_validation = 61,
                            horizons = c(1L, 6L), periode = 12)
mobile |>
  group_by(h, methode) |>
  summarise(n = n(), ME = mean(erreur), MAE = mean(abs(erreur)),
            RMSE = sqrt(mean(erreur^2)), .groups = "drop") |>
  knitr::kable(digits = 2)


## -----------------------------------------------------------------------------
# Vérifier l'information utilisée et la date de la cible.
mobile |>
  mutate(date_origine = electricite$date[origine], date_cible = electricite$date[cible]) |>
  select(methode, h, date_origine, date_cible, prevision, observe) |>
  filter(h == 6) |> head()


## -----------------------------------------------------------------------------
combinaison <- previsions |>
  mutate(prevision_combinee = (naive + saisonniere) / 2)
mesures_erreur(combinaison$consommation_kwh, combinaison$prevision_combinee,
               apprentissage$consommation_kwh, periode = 12)

