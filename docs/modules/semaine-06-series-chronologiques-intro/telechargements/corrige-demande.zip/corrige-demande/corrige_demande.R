## -----------------------------------------------------------------------------
#| label: preparation-exercices-06
library(tidyverse)
library(forecast)
chemins_R <- c("R/analyse-module06.R",
               "modules/semaine-06-series-chronologiques-intro/R/analyse-module06.R")
source(chemins_R[file.exists(chemins_R)][1])
chemins <- c("data/demande_hebdomadaire_quebec.csv",
             "data/demande_hebdomadaire_quebec.csv",
             "modules/atelier-03-series-chronologiques/data/demande_hebdomadaire_quebec.csv")
chemin <- chemins[file.exists(chemins)][1]
stopifnot(!is.na(chemin))
demande <- read_csv(chemin, show_col_types = FALSE) |>
  mutate(semaine = as.Date(semaine), promotion = factor(promotion)) |>
  arrange(semaine)
stopifnot(!anyNA(demande[c("semaine", "demande")]),
          !anyDuplicated(demande$semaine),
          all(as.numeric(diff(demande$semaine)) == 7))
apprentissage_demande <- demande |> slice_head(n = 91)
validation_demande <- demande |> slice_tail(n = 13)


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
ggplot(apprentissage_demande, aes(semaine, demande)) +
  geom_line(colour = "#0B4F6C") + geom_point(aes(colour = promotion)) +
  labs(x = NULL, y = "Demande hebdomadaire (unités)", colour = "Promotion") +
  theme_minimal()


## -----------------------------------------------------------------------------
#| fig-width: 9
#| fig-height: 4.5
ggplot(slice_tail(apprentissage_demande, n = 26), aes(semaine, demande)) +
  geom_line(colour = "#0B4F6C") + geom_point(aes(colour = promotion)) +
  labs(x = NULL, y = "Demande hebdomadaire (unités)", colour = "Promotion") +
  theme_minimal()


## -----------------------------------------------------------------------------
apprentissage_demande |>
  summarise(doublons = sum(duplicated(semaine)),
            pas_min = min(as.numeric(diff(semaine))),
            pas_max = max(as.numeric(diff(semaine))),
            manquants = sum(is.na(demande)))

incomplete <- apprentissage_demande |>
  mutate(demande = if_else(row_number() == 21L, NA_real_, as.numeric(demande))) |>
  slice(-20)
grille <- tibble(semaine = seq.Date(min(apprentissage_demande$semaine),
                                   max(apprentissage_demande$semaine), by = "week"))
grille |> left_join(incomplete, by = "semaine") |> filter(is.na(demande))


## -----------------------------------------------------------------------------
refs_demande <- prevoir_references(apprentissage_demande$demande, 13, periode = 52)
evaluation_demande <- validation_demande |>
  mutate(naive = refs_demande$naive, saisonniere = refs_demande$saisonniere) |>
  pivot_longer(c(naive, saisonniere), names_to = "methode", values_to = "prevision") |>
  mutate(erreur = demande - prevision)
evaluation_demande |> select(semaine, methode, prevision, demande) |> head()


## -----------------------------------------------------------------------------
comparaison_demande <- evaluation_demande |>
  group_by(methode) |>
  group_modify(~ mesures_erreur(.x$demande, .x$prevision,
                                apprentissage_demande$demande, periode = 52)) |>
  ungroup()
comparaison_demande |> knitr::kable(digits = 2)

mesures_erreur(c(0, 20), c(10, 20), c(10, 15, 20), periode = 1)


## -----------------------------------------------------------------------------
#| fig-width: 8
#| fig-height: 4.5
erreurs_demande <- evaluation_demande |> filter(methode == "saisonniere")
ggplot(erreurs_demande, aes(semaine, erreur)) +
  geom_hline(yintercept = 0, linetype = 2) + geom_line() + geom_point() +
  labs(x = NULL, y = "Erreur (unités)") + theme_minimal()


## -----------------------------------------------------------------------------
#| fig-width: 8
#| fig-height: 4.5
ggplot(erreurs_demande, aes(erreur)) +
  geom_histogram(bins = 6, fill = "#D9EEF2", colour = "#0B4F6C") +
  labs(x = "Erreur (unités)", y = "Semaines") + theme_minimal()


## -----------------------------------------------------------------------------
serie_demande <- ts(apprentissage_demande$demande, frequency = 52)
intervalle_naif <- naive(serie_demande, h = 8, level = c(80, 95))
tibble(h = c(2, 8), point = as.numeric(intervalle_naif$mean[c(2, 8)]),
       bas_80 = intervalle_naif$lower[c(2, 8), "80%"],
       haut_80 = intervalle_naif$upper[c(2, 8), "80%"],
       bas_95 = intervalle_naif$lower[c(2, 8), "95%"],
       haut_95 = intervalle_naif$upper[c(2, 8), "95%"])


## -----------------------------------------------------------------------------
mobile_demande <- validation_mobile(demande$demande, debut_validation = 92,
                                   horizons = c(2L, 8L), periode = 52)
mobile_demande |>
  group_by(h, methode) |>
  summarise(n = n(), ME = mean(erreur), MAE = mean(abs(erreur)),
            RMSE = sqrt(mean(erreur^2)), .groups = "drop") |>
  knitr::kable(digits = 2)


## -----------------------------------------------------------------------------
combinee_demande <- validation_demande |>
  mutate(prevision = (refs_demande$naive + refs_demande$saisonniere) / 2)
mesures_erreur(combinee_demande$demande, combinee_demande$prevision,
               apprentissage_demande$demande, periode = 52)


## -----------------------------------------------------------------------------
#| label: pratique-06-calendrier
library(tidyverse)
mesures_fictives <- tibble(
  mois = as.Date(c("2025-01-01", "2025-03-01")),
  quantite = c(10, 14)
)
calendrier_fictif <- tibble(
  mois = seq.Date(as.Date("2025-01-01"), as.Date("2025-03-01"), by = "month")
)
calendrier_fictif |> left_join(mesures_fictives, by = "mois")


## -----------------------------------------------------------------------------
#| label: pratique-06-origines
observations_fictives <- c(130, 150)
previsions_fixes <- c(120, 120)
previsions_un_pas <- c(120, 130)
data.frame(
  protocole = c("Origine fixe T, horizons 1 et 2", "Deux origines, horizon 1"),
  MAE = c(mean(abs(observations_fictives - previsions_fixes)),
          mean(abs(observations_fictives - previsions_un_pas)))
)


## -----------------------------------------------------------------------------
#| label: pratique-06-mesures
observations_mesures <- c(100, 100, 100)
previsions_mesures <- c(90, 110, 100)
erreurs_mesures <- observations_mesures - previsions_mesures
echelle_apprentissage <- 5
data.frame(
  ME = mean(erreurs_mesures),
  MAE = mean(abs(erreurs_mesures)),
  RMSE = sqrt(mean(erreurs_mesures^2)),
  MAPE = 100 * mean(abs(erreurs_mesures / observations_mesures)),
  MASE = mean(abs(erreurs_mesures)) / echelle_apprentissage
)

