# exemple-laboratoire-03

Décompressez le dossier et ouvrez le projet dans RStudio.
R, Quarto et tidyverse sont nécessaires. Rendez le fichier Quarto après avoir redémarré R.
La série représente 72 mois de livraisons fictives. Le bloc 2025 sert à choisir et n’est pas un test final indépendant.
Le script R/generer-livraisons.R régénère le CSV dans la copie courante à partir de la graine 210103.
Les coûts sont fictifs. La mission est une pratique distincte du mini-rapport.
Matériel du cours MQT-2101, Université Laval; données simulées pour le cours.
