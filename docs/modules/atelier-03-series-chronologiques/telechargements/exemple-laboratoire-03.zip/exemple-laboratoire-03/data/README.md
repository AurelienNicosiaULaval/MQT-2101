# Données de livraisons fictives

Une ligne représente un mois de janvier 2020 à décembre 2025.
date : premier jour du mois; livraisons : nombre simulé de livraisons durant le mois.
La série ne comporte aucune valeur manquante; les observations successives sont temporellement liées.
