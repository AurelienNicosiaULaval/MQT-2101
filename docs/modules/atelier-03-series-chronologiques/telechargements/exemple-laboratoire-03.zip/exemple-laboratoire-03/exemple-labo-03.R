## -----------------------------------------------------------------------------
#| label: preparation-labo03
library(tidyverse)
library(forecast)
demande <- read_csv("data/demande_hebdomadaire_quebec.csv", show_col_types = FALSE) |>
  mutate(semaine = as.Date(semaine)) |> arrange(semaine) |>
  mutate(indice = row_number())
stopifnot(nrow(demande) == 104L, !anyNA(demande[c("semaine", "demande")]),
          !anyDuplicated(demande$semaine),
          all(as.numeric(diff(demande$semaine)) == 7))
horizon <- 13L
apprentissage <- demande |> slice_head(n = 91)
validation <- demande |> slice_tail(n = horizon)
# La date identifie le lundi. Une semaine complète est connue le dimanche suivant.
origine <- max(apprentissage$semaine) + 6
futur <- tibble(semaine = seq.Date(max(apprentissage$semaine) + 7,
                                   by = "week", length.out = horizon),
                indice = 91L + seq_len(horizon))
serie <- ts(apprentissage$demande, frequency = 52)
stopifnot(all(futur$semaine == validation$semaine))


## -----------------------------------------------------------------------------
#| label: audit-labo03
demande |> summarise(lignes = n(), dates_distinctes = n_distinct(semaine),
  premiere_semaine = min(semaine), derniere_semaine = max(semaine),
  manquants = sum(is.na(demande)))
tibble(derniere_semaine_apprentissage = max(apprentissage$semaine),
       origine_fin_de_semaine = origine,
       premiere_semaine_validation = min(validation$semaine), horizon)


## -----------------------------------------------------------------------------
#| label: exploration-labo03
#| fig-width: 9
#| fig-height: 4.2
ggplot(apprentissage, aes(semaine, demande)) +
  geom_line(colour = "#0B4F6C") + geom_point(aes(shape = promotion), size = 1.5) +
  labs(x = NULL, y = "Demande hebdomadaire (unités de produit)",
       shape = "Promotion observée") + theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: previsions-labo03
# Tous les paramètres et les valeurs de référence viennent de l’apprentissage.
modele_ses <- ses(serie, h = horizon, initial = "optimal", level = c(80, 95))
modele_tendance <- lm(demande ~ indice, data = apprentissage)
previsions <- futur |>
  mutate(Naive = tail(apprentissage$demande, 1),
         MM4 = mean(tail(apprentissage$demande, 4)),
         SES = as.numeric(modele_ses$mean),
         Saisonnier = as.numeric(snaive(serie, h = horizon)$mean),
         Tendance = as.numeric(predict(modele_tendance, newdata = futur)))
previsions |> slice_head(n = 3)
coef(modele_tendance)


## -----------------------------------------------------------------------------
#| label: comparaison-labo03
#| fig-width: 9
#| fig-height: 4.2
# Les observations de validation ne sont jointes qu’après la prévision.
evaluation <- previsions |>
  left_join(validation |> select(semaine, observe = demande), by = "semaine") |>
  pivot_longer(c(Naive, MM4, SES, Saisonnier, Tendance),
               names_to = "methode", values_to = "prevision") |>
  mutate(erreur = observe - prevision)
scores <- evaluation |> group_by(methode) |>
  summarise(ME = mean(erreur), MAE = mean(abs(erreur)),
            RMSE = sqrt(mean(erreur^2)), .groups = "drop") |> arrange(MAE)
scores
ggplot(evaluation, aes(semaine)) +
  geom_line(aes(y = observe), colour = "black", linewidth = 1) +
  geom_line(aes(y = prevision, colour = methode)) +
  labs(x = NULL, y = "Demande hebdomadaire (unités de produit)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: intervalles-labo03
intervalles_ses <- tibble(semaine = futur$semaine,
  prevision = as.numeric(modele_ses$mean),
  inf80 = as.numeric(modele_ses$lower[, "80%"]),
  sup80 = as.numeric(modele_ses$upper[, "80%"]),
  inf95 = as.numeric(modele_ses$lower[, "95%"]),
  sup95 = as.numeric(modele_ses$upper[, "95%"]))
intervalles_ses |> slice_head(n = 3)


## -----------------------------------------------------------------------------
#| label: couts-labo03
couts <- evaluation |>
  mutate(cout = 18 * pmax(erreur, 0) + 5 * pmax(-erreur, 0)) |>
  group_by(methode) |>
  summarise(cout_total = sum(cout), .groups = "drop") |> arrange(cout_total)
couts


## -----------------------------------------------------------------------------
#| label: holt-labo03
modele_holt <- holt(serie, h = horizon, damped = TRUE,
                    initial = "optimal", level = c(80, 95))
holt_validation <- tibble(semaine = futur$semaine,
  observe = validation$demande, prevision = as.numeric(modele_holt$mean)) |>
  mutate(erreur = observe - prevision)
holt_validation |> summarise(ME = mean(erreur), MAE = mean(abs(erreur)),
  RMSE = sqrt(mean(erreur^2)),
  cout_total = sum(18 * pmax(erreur, 0) + 5 * pmax(-erreur, 0)))
tibble(semaine = futur$semaine, prevision = as.numeric(modele_holt$mean),
       inf80 = as.numeric(modele_holt$lower[, "80%"]),
       sup80 = as.numeric(modele_holt$upper[, "80%"]),
       inf95 = as.numeric(modele_holt$lower[, "95%"]),
       sup95 = as.numeric(modele_holt$upper[, "95%"])) |> slice_head(n = 3)


## -----------------------------------------------------------------------------
#| label: erreur-max-labo03
evaluation |> group_by(methode) |>
  summarise(erreur_max = max(abs(erreur)), .groups = "drop") |>
  arrange(erreur_max)

