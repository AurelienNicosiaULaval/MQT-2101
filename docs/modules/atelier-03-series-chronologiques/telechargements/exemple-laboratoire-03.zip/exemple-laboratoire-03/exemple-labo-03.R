## -----------------------------------------------------------------------------
#| label: preparation-labo03-mensuel
library(tidyverse)
livraisons <- read_csv('data/livraisons_mensuelles_fictives.csv', show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |> arrange(date) |>
  mutate(indice = row_number(), mois = factor(format(date, '%m'), levels = sprintf('%02d', 1:12)))
stopifnot(nrow(livraisons) == 72L, !anyDuplicated(livraisons$date),
          identical(livraisons$date[1], as.Date('2020-01-01')),
          identical(livraisons$date[72], as.Date('2025-12-01')),
          !anyNA(livraisons$livraisons),
          all(diff(12L * as.integer(format(livraisons$date, '%Y')) +
                     as.integer(format(livraisons$date, '%m'))) == 1L))
apprentissage <- livraisons |> slice_head(n = 60)
validation <- livraisons |> slice_tail(n = 12)


## -----------------------------------------------------------------------------
ggplot(apprentissage, aes(date, livraisons)) +
  geom_line(colour = '#0B4F6C') +
  labs(x = 'Mois', y = 'Livraisons par mois') + theme_minimal()

ggplot(apprentissage, aes(mois, livraisons, group = format(date, '%Y'),
                          colour = format(date, '%Y'))) +
  geom_line() + labs(x = 'Mois', y = 'Livraisons par mois', colour = 'Année') +
  theme_minimal()



## -----------------------------------------------------------------------------
modele <- lm(livraisons ~ indice + mois, data = apprentissage)
summary(modele)$coefficients[c('indice', 'mois12'), , drop = FALSE]
futur <- tibble(date = seq(as.Date('2025-01-01'), by = 'month', length.out = 12),
                indice = 61:72,
                mois = factor(sprintf('%02d', 1:12), levels = sprintf('%02d', 1:12)))
stopifnot(identical(futur$date, validation$date))
intervalle <- predict(modele, newdata = futur, interval = 'prediction', level = 0.95)


## -----------------------------------------------------------------------------
comparaison <- futur |>
  transmute(date, observe = validation$livraisons,
            `Naïf saisonnier` = tail(apprentissage$livraisons, 12),
            `Tendance et mois` = as.numeric(intervalle[, 'fit'])) |>
  pivot_longer(-c(date, observe), names_to = 'methode', values_to = 'prevision') |>
  mutate(erreur = observe - prevision,
         cout = 2 * pmax(erreur, 0) + pmax(-erreur, 0))
comparaison |>
  group_by(methode) |>
  summarise(ME = mean(erreur), MAE = mean(abs(erreur)),
            RMSE = sqrt(mean(erreur^2)), cout_total_dollars = sum(cout), .groups = 'drop')

ggplot(comparaison, aes(date, prevision, colour = methode)) +
  geom_line() + geom_line(aes(y = observe), colour = 'black', linewidth = 0.8) +
  labs(x = 'Mois de validation', y = 'Livraisons par mois',
       colour = 'Prévision', caption = 'Noir : livraisons observées') + theme_minimal()

intervalle[1, , drop = FALSE]

