## -----------------------------------------------------------------------------
#| label: preparation-exercices-04
library(tidyverse)

# Afficher les résultats avec une virgule décimale dans le texte du rapport.
nombre_fr <- function(x, decimales = 3) {
  formatC(x, format = "f", digits = decimales, big.mark = " ", decimal.mark = ",")
}

service <- read_csv("data/cas_integrateur_quebec.csv",
                    show_col_types = FALSE) |>
  mutate(date = as.Date(date), succursale = factor(succursale)) |>
  arrange(date, succursale)

stopifnot(!anyNA(service[c("date", "taux_utilisation", "temps_attente")]))

# Garder l’année 2025 pour comparer les deux modèles.
apprentissage <- service |> filter(date < as.Date("2025-01-01"))
validation <- service |> filter(date >= as.Date("2025-01-01"))


## -----------------------------------------------------------------------------
#| label: solution-04-1
#| fig-width: 9
#| fig-height: 5
tibble(ensemble = c("Apprentissage", "Validation"),
       observations = c(nrow(apprentissage), nrow(validation)),
       mois = c(n_distinct(apprentissage$date), n_distinct(validation$date)),
       succursales = c(n_distinct(apprentissage$succursale),
                      n_distinct(validation$succursale)))

ggplot(apprentissage, aes(taux_utilisation, temps_attente)) +
  geom_point(aes(colour = succursale), alpha = 0.7, size = 2.1) +
  scale_x_continuous(labels = scales::label_percent()) +
  labs(x = "Taux d’utilisation", y = "Attente moyenne (minutes)", colour = "Succursale") +
  theme_minimal(base_size = 13)


## -----------------------------------------------------------------------------
#| label: solution-04-2
#| fig-width: 9
#| fig-height: 5
modele_lineaire <- lm(temps_attente ~ taux_utilisation, data = apprentissage)
modele_quadratique <- lm(
  temps_attente ~ taux_utilisation + I(taux_utilisation^2),
  data = apprentissage
)
coef(modele_lineaire)
coef(modele_quadratique)
tibble(modele = c("Linéaire", "Quadratique"),
       r2_apprentissage = c(summary(modele_lineaire)$r.squared,
                             summary(modele_quadratique)$r.squared))

grille <- tibble(taux_utilisation = seq(min(apprentissage$taux_utilisation),
                                        max(apprentissage$taux_utilisation),
                                        length.out = 120))
courbes <- bind_rows(
  grille |> mutate(modele = "Linéaire", attente_predite = predict(modele_lineaire, newdata = grille)),
  grille |> mutate(modele = "Quadratique", attente_predite = predict(modele_quadratique, newdata = grille))
)
ggplot(apprentissage, aes(taux_utilisation, temps_attente)) +
  geom_point(alpha = 0.4) +
  geom_line(data = courbes, aes(y = attente_predite, colour = modele), linewidth = 1.1) +
  scale_x_continuous(labels = scales::label_percent()) +
  labs(x = "Taux d’utilisation", y = "Attente moyenne (minutes)", colour = "Modèle") +
  theme_minimal(base_size = 13)

unname(coef(modele_lineaire)[2] * 0.10)
# La quadratique exige une différence de prédictions.
scenarios_taux <- tibble(taux_utilisation = c(0.80, 0.90, 1.00))
predictions_taux <- predict(modele_quadratique, newdata = scenarios_taux)
tibble(comparaison = c("80 % à 90 %", "90 % à 100 %"),
       difference_minutes = diff(predictions_taux))


## -----------------------------------------------------------------------------
#| label: solution-04-3
rmse <- function(observe, predit) {
  stopifnot(length(observe) == length(predit), !anyNA(observe), !anyNA(predit))
  sqrt(mean((observe - predit)^2))
}
comparaison <- tibble(
  modele = c("Linéaire", "Quadratique"),
  rmse_apprentissage = c(rmse(apprentissage$temps_attente, fitted(modele_lineaire)),
                         rmse(apprentissage$temps_attente, fitted(modele_quadratique))),
  rmse_validation = c(rmse(validation$temps_attente, predict(modele_lineaire, newdata = validation)),
                      rmse(validation$temps_attente, predict(modele_quadratique, newdata = validation)))
)
comparaison
ecart_minutes <- comparaison$rmse_validation[2] - comparaison$rmse_validation[1]
tibble(ecart_minutes = ecart_minutes, ecart_secondes = 60 * ecart_minutes)


## -----------------------------------------------------------------------------
#| label: solution-04-4
#| fig-width: 9
#| fig-height: 5
plage <- range(apprentissage$taux_utilisation)
plage
sum(validation$taux_utilisation < plage[1] |
    validation$taux_utilisation > plage[2])

diagnostic <- apprentissage |>
  mutate(attente_predite = fitted(modele_lineaire), residu = residuals(modele_lineaire))
ggplot(diagnostic, aes(attente_predite, residu, colour = succursale)) +
  geom_hline(yintercept = 0, colour = "#7A1C24") +
  geom_point(alpha = 0.7) +
  labs(x = "Attente ajustée (minutes)", y = "Résidu (minutes)", colour = "Succursale") +
  theme_minimal(base_size = 13)
diagnostic |>
  group_by(succursale) |>
  summarise(residu_moyen = mean(residu), erreur_absolue_moyenne = mean(abs(residu)),
            .groups = "drop")

scenarios <- tibble(taux_utilisation = c(0.90, 1.50))
intervalles <- predict(modele_lineaire, newdata = scenarios,
                       interval = "prediction", level = 0.95)
bind_cols(scenarios, as_tibble(intervalles))


## -----------------------------------------------------------------------------
#| label: solution-04-7
pieces_centaines <- c(2, 3, 4)
consommation <- 40 + 6 * pieces_centaines + 0.8 * pieces_centaines^2
data.frame(pieces = 100 * pieces_centaines, kWh_predits = consommation)
diff(consommation)


## -----------------------------------------------------------------------------
#| label: solution-04-8
predire_temps <- function(dossiers) {
  stopifnot(all(dossiers > 0))
  12 + 4 * log(dossiers)
}
x <- c(20, 40, 80)
data.frame(dossiers = x, minutes = predire_temps(x))
c(doubler_20 = predire_temps(40) - predire_temps(20),
  doubler_40 = predire_temps(80) - predire_temps(40),
  hausse_10_pourcent = predire_temps(22) - predire_temps(20))


## -----------------------------------------------------------------------------
#| label: solution-04-9
x_km <- 2
z_m <- 2000
c(kilometres = 80 + 12 * x_km + 2 * x_km^2,
  metres = 80 + 0.012 * z_m + 0.000002 * z_m^2)
# Vérification du logarithme sur un exemple de coefficients.
a <- 80
b <- 12
c(kilometres = a + b * log(x_km),
  metres = (a - b * log(1000)) + b * log(z_m))


## -----------------------------------------------------------------------------
#| label: solution-04-10
observe <- c(8, 10, 12, 14)
pred_A <- c(10, 8, 14, 12)
pred_B <- c(8, 10, 12, 18)
mesurer <- function(predit) {
  erreur <- observe - predit
  c(moyenne = mean(erreur), MAE = mean(abs(erreur)),
    RMSE = sqrt(mean(erreur^2)))
}
rbind(A = mesurer(pred_A), B = mesurer(pred_B))
data.frame(erreur_A = observe - pred_A, erreur_B = observe - pred_B)


## -----------------------------------------------------------------------------
#| label: solution-04-12
library(tidyverse)
exemple_residus <- tibble(
  centre = rep(c("A", "B"), each = 3),
  ajuste = rep(c(10, 12, 14), 2),
  residu = c(-2, -1, -3, 2, 1, 3)
)
mean(exemple_residus$residu)
exemple_residus |>
  group_by(centre) |>
  summarise(residu_moyen_minutes = mean(residu), .groups = "drop")
ggplot(exemple_residus, aes(ajuste, residu, colour = centre)) +
  geom_hline(yintercept = 0) +
  geom_point(size = 3) +
  labs(x = "Temps ajusté (minutes)", y = "Résidu (minutes)", colour = "Centre") +
  theme_minimal()


## -----------------------------------------------------------------------------
#| label: solution-04-13
lots <- data.frame(x = 1:6, y = c(2.4, 3.1, 4.2, 4.7, 5.9, 6.4))
ajustement_lots <- lm(y ~ x, data = lots)
scenarios_lots <- data.frame(x = c(3.5, 12))
ic_lots <- predict(ajustement_lots, newdata = scenarios_lots,
                   interval = "confidence", level = 0.95)
ip_lots <- predict(ajustement_lots, newdata = scenarios_lots,
                   interval = "prediction", level = 0.95)
cbind(scenarios_lots, ic_lots)
cbind(scenarios_lots, ip_lots)

