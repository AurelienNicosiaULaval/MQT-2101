# Corrigés des quatorze exercices

1. Décompressez toute l’archive avant d’ouvrir le fichier .Rproj.
2. Les préalables sont R, RStudio, Quarto et le package tidyverse (voir le guide d’installation du cours).
3. Ouvrez le document .qmd. Le dossier data contient le CSV et les dictionnaires.
4. Après votre tentative, exécutez le code dans l’ordre ou cliquez sur Render. Le script .R reprend tous les calculs.
5. Redémarrez R, puis utilisez Render : le document doit se recalculer sans objets de console.

Parcours : https://aureliennicosiaulaval.github.io/MQT-2101/modules/semaine-04-regression-nonlineaire/index.html
Les données sont simulées pour l’enseignement. Ces projets sont des entraînements et ne constituent pas une remise évaluée.
