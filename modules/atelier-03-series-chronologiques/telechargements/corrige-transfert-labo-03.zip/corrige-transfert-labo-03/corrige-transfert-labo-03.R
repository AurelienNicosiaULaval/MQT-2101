## -----------------------------------------------------------------------------
#| label: preparation-transfert-labo03
library(tidyverse)
ventes <- read_csv("data/ventes_saisonnieres_quebec.csv", show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |> arrange(date) |>
  mutate(indice = row_number(), mois = factor(lubridate::month(date), levels = 1:12))
stopifnot(nrow(ventes) == 72L, !anyNA(ventes[c("date", "ventes")]),
          !anyDuplicated(ventes$date),
          identical(ventes$date, seq.Date(as.Date("2020-01-01"), by = "month", length.out = 72)))
apprentissage <- ventes |> slice_head(n = 60)
validation <- ventes |> slice_tail(n = 12)
futur <- tibble(date = seq.Date(as.Date("2025-01-01"), by = "month", length.out = 12),
                indice = 61:72, mois = factor(1:12, levels = 1:12))
stopifnot(identical(futur$date, validation$date))


## -----------------------------------------------------------------------------
#| label: transfert-labo03-previsions
# Ajuster sur 2020-2024 et construire les prévisions avant les observations de 2025.
modele_calendrier <- lm(ventes ~ indice + mois, data = apprentissage,
                        contrasts = list(mois = "contr.treatment"))
previsions <- futur |>
  mutate(Calendrier = as.numeric(predict(modele_calendrier, newdata = futur)),
         Saisonnier = tail(apprentissage$ventes, 12))
evaluation <- previsions |>
  left_join(validation |> select(date, observe = ventes), by = "date") |>
  pivot_longer(c(Calendrier, Saisonnier), names_to = "methode", values_to = "prevision") |>
  mutate(erreur = observe - prevision)
evaluation |> group_by(methode) |>
  summarise(ME = mean(erreur), MAE = mean(abs(erreur)),
            RMSE = sqrt(mean(erreur^2)), .groups = "drop")

## -----------------------------------------------------------------------------
#| label: transfert-labo03-graphique
#| fig-width: 9
#| fig-height: 4.2
ggplot(evaluation, aes(date)) +
  geom_line(aes(y = observe / 1000), colour = "black", linewidth = 1) +
  geom_line(aes(y = prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Ventes (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: transfert-labo03-couts
# Un scénario pédagogique, défini avant de calculer les erreurs.
couts_previsions <- evaluation |>
  mutate(cout_fictif = 1.5 * pmax(erreur, 0) + 0.4 * pmax(-erreur, 0)) |>
  group_by(methode) |>
  summarise(MAE = mean(abs(erreur)), cout_total = sum(cout_fictif), .groups = "drop")
couts_previsions
# Comparaison rétrospective à un objectif, pas une nouvelle prévision.
budget_retro <- validation |>
  mutate(ecart_objectif = ventes - budget_cible,
         cout_fictif = 1.5 * pmax(ecart_objectif, 0) + 0.4 * pmax(-ecart_objectif, 0)) |>
  summarise(MAE_ecart_objectif = mean(abs(ecart_objectif)),
            cout_total = sum(cout_fictif), mois_au_dessus = sum(ecart_objectif > 0))
budget_retro


## -----------------------------------------------------------------------------
#| label: transfert-labo03-intervalles
intervalle <- predict(modele_calendrier, newdata = futur,
                      interval = "prediction", level = 0.95)
verif_intervalle <- tibble(date = futur$date, observe = validation$ventes,
  fit = intervalle[, "fit"], inf = intervalle[, "lwr"], sup = intervalle[, "upr"]) |>
  mutate(dans_intervalle = observe >= inf & observe <= sup)
verif_intervalle |> summarise(mois_couverts = sum(dans_intervalle), mois = n())


## -----------------------------------------------------------------------------
#| label: pratique-cout-asymetrique
exemple <- tibble(methode = rep(c("A", "B"), each = 2),
                  erreur = c(10, 0, -6, -6)) |>
  group_by(methode) |>
  summarise(MAE = mean(abs(erreur)),
            cout_total = sum(18 * pmax(erreur, 0) + 5 * pmax(-erreur, 0)),
            .groups = "drop")
exemple

