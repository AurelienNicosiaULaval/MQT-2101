# transfert-labo-03

Version locale du 27 octobre 2026.
1. Décompressez toute l’archive et ouvrez le .Rproj dans RStudio.
2. Installez une fois tidyverse et forecast si nécessaire. R, RStudio et Quarto sont requis.
3. Ouvrez le .qmd, redémarrez R et faites Render. Conservez data/ et R/.
4. Le premier rendu fonctionne; ajoutez ensuite vos résultats et interprétations aux sections.
Cette pratique est facultative et ne crée pas un deuxième rapport obligatoire.
Les deux jeux sont fictifs, entièrement simulés et redistribuables avec le cours.
Les périodes de validation sont déjà connues; les scores servent au choix, sans test final indépendant.
Coûts pédagogiques fictifs; aucune commande ni politique de stock optimale n’est calculée.
Pour reproduire les CSV dans la copie seulement : source("R/regenerer-donnees.R").
Attribution : matériel du cours MQT-2101, Université Laval; données simulées du cours.
Les anciennes archives, données de tiers et fichiers enseignants ne sont pas inclus.
