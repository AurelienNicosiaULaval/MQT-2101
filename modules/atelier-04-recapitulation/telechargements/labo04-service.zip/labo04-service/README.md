# Projet du laboratoire 04

Décompressez l’archive entière et ouvrez le fichier .Rproj. Installez tidyverse et lubridate, puis rendez le .qmd dans une session neuve. Données fictives : voir data/dictionnaires.md. Le script R/regenerer-donnees.R réécrit les deux CSV locaux. Les périodes réutilisées ne sont pas de nouveaux tests indépendants. Matériel MQT-2101, Université Laval.
