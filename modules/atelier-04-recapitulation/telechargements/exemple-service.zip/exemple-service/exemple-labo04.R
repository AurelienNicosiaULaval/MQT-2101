library(tidyverse)
library(lubridate)

racines <- c(".", "modules/atelier-04-recapitulation")
racine <- racines[file.exists(file.path(racines, "data/cas_integrateur_quebec.csv"))][1]
stopifnot(!is.na(racine))
cas <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date), succursale = factor(succursale),
         promotion = factor(promotion, levels = c("non", "oui")),
         mois = factor(month(date), levels = 1:12)) |> arrange(date, succursale)
stopifnot(nrow(cas) == 288, n_distinct(cas$succursale) == 4,
          !anyDuplicated(cas[c("date", "succursale")]), !anyNA(cas))
cas |> summarise(lignes = n(), debut = min(date), fin = max(date),
                  succursales = n_distinct(succursale), mois = n_distinct(date))


# Explorer la cible binaire sur la seule période d'apprentissage.
cas |> filter(date <= as.Date("2023-11-01")) |>
  group_by(succursale) |>
  summarise(proportion = mean(service_insuffisant_mois_suivant), .groups = "drop") |>
  ggplot(aes(succursale, proportion)) + geom_col(fill = "#b20d23") +
  labs(x = "Succursale", y = "Proportion de service insuffisant simulé") +
  theme_minimal(base_size = 11)


mesures_binaires <- function(observe, prediction) {
  stopifnot(length(observe) == length(prediction), all(observe %in% c(0, 1)),
            all(prediction %in% c(0, 1)))
  vp <- sum(observe == 1 & prediction == 1); fp <- sum(observe == 0 & prediction == 1)
  vn <- sum(observe == 0 & prediction == 0); fn <- sum(observe == 1 & prediction == 0)
  ratio <- function(a, b) if (b == 0) NA_real_ else a / b
  tibble(VP = vp, FP = fp, VN = vn, FN = fn,
         sensibilite = ratio(vp, vp + fn), specificite = ratio(vn, vn + fp),
         precision = ratio(vp, vp + fp), proportion_ciblee = mean(prediction == 1))
}


apprentissage_b <- cas |> filter(date <= as.Date("2023-11-01"))
validation_b <- cas |> filter(date >= as.Date("2024-01-01"), date <= as.Date("2024-11-01"))
evaluation_b <- cas |> filter(date >= as.Date("2025-01-01"))
modele_service <- glm(service_insuffisant_mois_suivant ~ temps_attente + ruptures_stock +
                        satisfaction + taux_utilisation, data = apprentissage_b, family = binomial())
stopifnot(modele_service$converged, all(is.finite(coef(modele_service))))
validation_b <- validation_b |>
  mutate(prob_risque = as.numeric(predict(modele_service, newdata = validation_b, type = "response")))
# Seuil défini sur les scores de 2024, sans utiliser les étiquettes de 2025.
seuil_b <- as.numeric(quantile(validation_b$prob_risque, 0.80))
evaluation_b <- evaluation_b |>
  mutate(prob_risque = as.numeric(predict(modele_service, newdata = evaluation_b, type = "response")),
         prediction = as.integer(prob_risque >= seuil_b))
classe_majoritaire <- as.integer(mean(apprentissage_b$service_insuffisant_mois_suivant) > 0.5)
mesure_b <- mesures_binaires(evaluation_b$service_insuffisant_mois_suivant, evaluation_b$prediction)
reference_b <- mesures_binaires(evaluation_b$service_insuffisant_mois_suivant,
                                 rep(classe_majoritaire, nrow(evaluation_b)))
seuil_b
mesure_b |> select(VP, FP, VN, FN)
mesure_b |> select(sensibilite, specificite, precision, proportion_ciblee)
reference_b |> select(VP, FP, VN, FN, sensibilite, precision)


evaluation_b |> group_by(succursale) |>
  summarise(observations = n(), cibles = sum(prediction),
            taux_cible = mean(prediction), positifs = sum(service_insuffisant_mois_suivant),
            .groups = "drop")
