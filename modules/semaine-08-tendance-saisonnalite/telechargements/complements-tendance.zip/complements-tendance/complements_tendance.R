## -----------------------------------------------------------------------------
#| label: preparation-complements-08
library(tidyverse)
library(broom)
source("R/fonctions-module08.R")
ventes <- read_csv("data/ventes_saisonnieres_quebec.csv", show_col_types = FALSE) |>
  preparer_calendrier()
stopifnot(nrow(ventes) == 72L)
apprentissage <- ventes |> slice_head(n = 60)
validation <- ventes |> slice_tail(n = 12)
# Les prédicteurs futurs sont construits sans les ventes ni le budget de validation.
futur <- calendrier_futur("2025-01-01", horizon = 12, dernier_indice = 60)
serie <- ts(apprentissage$ventes, frequency = 12, start = c(2020, 1))

## -----------------------------------------------------------------------------
#| label: modeles-base-complements-08
# La cible, le calendrier et la séparation sont vérifiés avant l’ajustement.
apprentissage |> select(date, indice_temps, mois) |> slice(c(1, 2, 12, 13, 60))
modele_tendance <- lm(ventes ~ indice_temps, data = apprentissage)
modele_saison <- lm(ventes ~ mois, data = apprentissage,
                    contrasts = list(mois = "contr.treatment"))
modele_calendrier <- lm(ventes ~ indice_temps + mois, data = apprentissage,
                        contrasts = list(mois = "contr.treatment"))
modeles <- list(Tendance = modele_tendance, Saison = modele_saison,
                Calendrier = modele_calendrier)
model.matrix(modele_calendrier)[c(1, 2, 12), c(1, 2, 3, 13)]
tidy(modele_calendrier, conf.int = TRUE) |>
  filter(term %in% c("indice_temps", "moisdécembre"))


## -----------------------------------------------------------------------------
#| label: formes-complements-08
modele_quadratique <- lm(ventes ~ indice_temps + I(indice_temps^2), data = apprentissage)
modele_exponentiel <- lm(log(ventes) ~ indice_temps, data = apprentissage)
modele_calendrier_quad <- lm(ventes ~ indice_temps + I(indice_temps^2) + mois,
                            data = apprentissage, contrasts = list(mois = "contr.treatment"))
modele_calendrier_log <- lm(log(ventes) ~ indice_temps + mois,
                           data = apprentissage, contrasts = list(mois = "contr.treatment"))
formes <- list(Quadratique = modele_quadratique, Exponentielle = modele_exponentiel,
               Calendrier_quad = modele_calendrier_quad, Calendrier_log = modele_calendrier_log)
previsions_formes <- imap_dfr(formes, function(modele, nom) {
  tibble(date = futur$date, observe = validation$ventes, methode = nom,
         prevision = prevoir_original(modele, futur, nom %in% c("Exponentielle", "Calendrier_log")))
})
previsions_formes |> group_by(methode) |>
  group_modify(~ mesures08(.x$observe, .x$prevision)) |> ungroup() |> arrange(MAE)
tibble(pourcentage_mensuel = 100 * (exp(coef(modele_exponentiel)[["indice_temps"]]) - 1),
       mediane_janvier = exp(predict(modele_exponentiel, futur)[1]),
       moyenne_janvier_approchee = prevoir_original(modele_exponentiel, futur, TRUE)[1])


## -----------------------------------------------------------------------------
#| label: decomposition-complements-08
#| fig-width: 9
#| fig-height: 5.2
ggplot(apprentissage, aes(ventes / 1000)) +
  geom_histogram(bins = 12, fill = "#0B4F6C", colour = "white") +
  labs(x = "Ventes mensuelles (milliers de $ CA)", y = "Nombre de mois") +
  theme_minimal(base_size = 12)
decomposition_add <- decompose(serie, type = "additive")
decomposition_mult <- decompose(serie, type = "multiplicative")
indices_saisonniers <- tibble(mois = factor(mois_fr, levels = mois_fr),
  ecart_dollars = as.numeric(decomposition_add$figure),
  facteur = as.numeric(decomposition_mult$figure))
indices_saisonniers |> arrange(desc(facteur))
plot(decomposition_mult)


## -----------------------------------------------------------------------------
#| label: harmoniques-complements-08
#| fig-width: 9
#| fig-height: 4.3
modele_harmonique <- lm(
  ventes ~ indice_temps + I(indice_temps^2) + sinus + cosinus,
  data = apprentissage
)
mesures08(validation$ventes, as.numeric(predict(modele_harmonique, futur)))
# Un seul couple sinus/cosinus, fixé avant les scores; période de 12 mois.
profil <- calendrier_futur("2025-01-01", 12, 60)
profil |>
  transmute(date, mois, sinus, cosinus,
            Calendrier = predict(modele_calendrier, newdata = profil),
            Harmonique = predict(modele_harmonique, newdata = profil)) |>
  pivot_longer(c(Calendrier, Harmonique), names_to = "methode", values_to = "prevision") |>
  ggplot(aes(date, prevision / 1000, colour = methode)) +
  geom_line() + geom_point() +
  labs(x = NULL, y = "Ventes prévues (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: anciens-scripts-complements-08
library(forecast)
modele_tslm <- tslm(serie ~ trend + season)
max(abs(fitted(modele_tslm) - fitted(modele_calendrier)))
max(abs(as.numeric(BoxCox(serie, lambda = 0)) - log(as.numeric(serie))))


## -----------------------------------------------------------------------------
#| label: stationnarite-complements-08
#| warning: true
#| fig-width: 9
#| fig-height: 6
library(tseries)
# Les tests sont explicitement distincts. Les avertissements sur les bornes
# de la table des valeurs p restent visibles dans le complément.
kpss_niveau <- kpss.test(serie, null = "Level")
kpss_tendance <- kpss.test(serie, null = "Trend")
kpss_difference <- kpss.test(diff(serie), null = "Level")
tibble(hypothese = c("Niveau stationnaire", "Stationnaire autour d’une tendance",
                     "Différence simple: niveau stationnaire"),
       statistique = c(unname(kpss_niveau$statistic), unname(kpss_tendance$statistic),
                       unname(kpss_difference$statistic)),
       p_table = c(kpss_niveau$p.value, kpss_tendance$p.value, kpss_difference$p.value))
par(mfrow = c(2, 2))
plot(serie, main = "Niveau", ylab = "$ CA", xlab = "Année")
plot(diff(serie), main = "Différence à un mois", ylab = "Différence ($ CA)", xlab = "Année")
plot(diff(serie, lag = 12), main = "Différence à douze mois", ylab = "Différence ($ CA)", xlab = "Année")
plot(diff(diff(serie, lag = 12)), main = "Deux différences", ylab = "Différence ($ CA)", xlab = "Année")
par(mfrow = c(1, 1))

