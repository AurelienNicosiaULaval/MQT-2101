## -----------------------------------------------------------------------------
#| label: preparation-transfert-m08
library(tidyverse)
library(broom)
source("R/fonctions-module08.R")
commerce <- read_csv("data/ventes_promotions_quebec.csv", show_col_types = FALSE) |>
  preparer_calendrier()
stopifnot(nrow(commerce) == 72L)
apprentissage <- commerce |> slice_head(n = 60)
validation <- commerce |> slice_tail(n = 12)
# Les prédicteurs futurs sont construits sans les ventes ni le budget de validation.
futur <- calendrier_futur("2025-01-01", horizon = 12, dernier_indice = 60)
serie <- ts(apprentissage$ventes, frequency = 12, start = c(2020, 1))


## -----------------------------------------------------------------------------
#| label: solution-08-1
#| fig-width: 9
#| fig-height: 4.3
ggplot(apprentissage, aes(date, ventes / 1000)) +
  geom_line(colour = "#0B4F6C") + geom_point(aes(shape = promotion)) +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)") +
  theme_minimal(base_size = 12)
ggplot(apprentissage, aes(mois, ventes / 1000, group = factor(annee), colour = factor(annee))) +
  geom_line() + geom_point() +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)", colour = "Année") +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


## -----------------------------------------------------------------------------
#| label: solution-08-2
# La cible, le calendrier et la séparation sont vérifiés avant l’ajustement.
apprentissage |> select(date, indice_temps, mois) |> slice(c(1, 2, 12, 13, 60))
modele_tendance <- lm(ventes ~ indice_temps, data = apprentissage)
modele_saison <- lm(ventes ~ mois, data = apprentissage,
                    contrasts = list(mois = "contr.treatment"))
modele_calendrier <- lm(ventes ~ indice_temps + mois, data = apprentissage,
                        contrasts = list(mois = "contr.treatment"))
modeles <- list(Tendance = modele_tendance, Saison = modele_saison,
                Calendrier = modele_calendrier)
model.matrix(modele_calendrier)[c(1, 2, 12), c(1, 2, 3, 13)]
tidy(modele_calendrier, conf.int = TRUE) |>
  filter(term %in% c("indice_temps", "moisdécembre"))


## -----------------------------------------------------------------------------
#| label: solution-08-3
#| fig-width: 9
#| fig-height: 4.2
diagnostic <- apprentissage |>
  mutate(ajuste = fitted(modele_calendrier), residu = residuals(modele_calendrier))
ggplot(diagnostic, aes(date, residu / 1000)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_line() +
  labs(x = NULL, y = "Résidu (milliers de $ CA)") + theme_minimal(base_size = 12)
ggplot(diagnostic, aes(ajuste / 1000, residu / 1000)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_point() +
  labs(x = "Valeur ajustée (milliers de $ CA)", y = "Résidu (milliers de $ CA)") +
  theme_minimal(base_size = 12)
# Comparer ce qui reste par mois avec et sans terme de calendrier.
residus_mensuels <- imap_dfr(modeles, function(modele, nom) {
  tibble(mois = apprentissage$mois, residu = residuals(modele), methode = nom)
}) |>
  group_by(methode, mois) |> summarise(residu_moyen = mean(residu), .groups = "drop")
residus_mensuels |>
  ggplot(aes(mois, residu_moyen / 1000, colour = methode, group = methode)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_line() + geom_point() +
  labs(x = NULL, y = "Résidu mensuel moyen (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


## -----------------------------------------------------------------------------
#| label: solution-08-4
#| fig-width: 9
#| fig-height: 4.3
previsions <- imap_dfr(modeles, function(modele, nom) {
  tibble(date = futur$date, observe = validation$ventes, methode = nom,
         prevision = as.numeric(predict(modele, newdata = futur)))
}) |>
  bind_rows(tibble(date = futur$date, observe = validation$ventes,
                   methode = "Saisonnier_naif", prevision = tail(apprentissage$ventes, 12)))
scores <- previsions |> group_by(methode) |>
  group_modify(~ mesures08(.x$observe, .x$prevision)) |> ungroup() |> arrange(MAE)
scores
ggplot() +
  geom_line(data = validation, aes(date, ventes / 1000), linewidth = 1) +
  geom_line(data = previsions, aes(date, prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Ventes mensuelles (milliers de $ CA)", colour = "Méthode") +
  theme_minimal(base_size = 12)
previsions |> left_join(validation |> select(date, promotion), by = "date") |>
  filter(methode == "Calendrier") |>
  group_by(promotion) |>
  summarise(mois = n(), MAE = mean(abs(observe - prevision)), .groups = "drop")


## -----------------------------------------------------------------------------
#| label: solution-08-5
#| fig-width: 9
#| fig-height: 4.3
ip_commerce <- predict(modele_calendrier, futur, interval = "prediction", level = 0.95)
tibble(date = futur$date, observe = validation$ventes,
       fit = ip_commerce[, "fit"], lwr = ip_commerce[, "lwr"], upr = ip_commerce[, "upr"]) |>
  ggplot(aes(date)) +
  geom_ribbon(aes(ymin = lwr / 1000, ymax = upr / 1000), fill = "#BFDDE5", alpha = 0.6) +
  geom_line(aes(y = fit / 1000), colour = "#0B4F6C") +
  geom_point(aes(y = observe / 1000)) +
  labs(x = NULL, y = "Ventes (milliers de $ CA)",
       subtitle = "Intervalles classiques conditionnels au modèle, sans plan commercial futur") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: contexte-08
#| fig-width: 9
#| fig-height: 4.3
# Complément accompagné: les valeurs futures observées servent ici à une
# comparaison rétrospective conditionnelle, pas à une prévision réalisable ex ante.
apprentissage <- apprentissage |>
  mutate(promotion = factor(promotion, levels = c("non", "oui")))
validation <- validation |>
  mutate(promotion = factor(promotion, levels = c("non", "oui")))
modele_contexte_sans_mois <- lm(ventes ~ indice_temps + promotion + prix_moyen,
                               data = apprentissage)
modele_contexte <- lm(ventes ~ indice_temps + mois + promotion + prix_moyen,
                      data = apprentissage, contrasts = list(mois = "contr.treatment"))
augment(modele_contexte_sans_mois, data = apprentissage) |>
  group_by(mois) |> summarise(residu_moyen = mean(.resid), .groups = "drop") |>
  ggplot(aes(mois, residu_moyen, group = 1)) +
  geom_hline(yintercept = 0, colour = "grey60") + geom_line() + geom_point() +
  labs(x = NULL, y = "Résidu moyen ($ CA)") + theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
bind_rows(tidy(modele_calendrier) |> mutate(modele = "Calendrier"),
          tidy(modele_contexte) |> mutate(modele = "Calendrier et contexte")) |>
  filter(term %in% c("moisjuillet", "moisdécembre")) |>
  select(modele, term, estimate, std.error)
comparaison_conditionnelle <- bind_rows(
  validation |> transmute(date, promotion, observe = ventes,
    prevision = as.numeric(predict(modele_calendrier, futur)), modele = "Calendrier"),
  validation |> transmute(date, promotion, observe = ventes,
    prevision = as.numeric(predict(modele_contexte, validation)), modele = "Contexte observé")
)
comparaison_conditionnelle |> group_by(modele, promotion) |>
  summarise(mois = n(), MAE = mean(abs(observe - prevision)),
            ME = mean(observe - prevision), .groups = "drop")


## -----------------------------------------------------------------------------
#| label: scenario-08
# Scénario hypothétique déclaré, sans utilisation des prix observés de 2025.
# Le dernier prix d’apprentissage est répété. Deux plans de promotion sont comparés.
scenarios <- bind_rows(
  futur |> mutate(promotion = factor("non", levels = c("non", "oui")),
                   prix_moyen = tail(apprentissage$prix_moyen, 1), plan = "Sans promotion"),
  futur |> mutate(promotion = factor("oui", levels = c("non", "oui")),
                   prix_moyen = tail(apprentissage$prix_moyen, 1), plan = "Avec promotion")
)
scenarios$prevision <- as.numeric(predict(modele_contexte, newdata = scenarios))
scenarios |> select(date, plan, prix_moyen, prevision) |> slice(c(1, 13))

