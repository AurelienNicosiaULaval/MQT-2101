## -----------------------------------------------------------------------------
#| label: importation-demo-04
library(tidyverse)

# Afficher les résultats avec une virgule décimale dans le texte du rapport.
nombre_fr <- function(x, decimales = 0) {
  formatC(x, format = "f", digits = decimales, big.mark = " ", decimal.mark = ",")
}

saturation <- read_csv("data/achalandage_saturation_quebec.csv",
                       show_col_types = FALSE) |>
  mutate(mois = as.Date(mois),
         achalandage_milliers = achalandage / 1000)

# Arrêter l’analyse si les variables indispensables sont incomplètes.
stopifnot(!anyNA(saturation[c("mois", "achalandage", "ventes")]),
          all(saturation$achalandage > 0))

# Fixer la séparation avant d’examiner les résultats de validation.
apprentissage <- saturation |> filter(mois < as.Date("2025-10-01"))
validation <- saturation |> filter(mois >= as.Date("2025-10-01"))


## -----------------------------------------------------------------------------
#| label: structure-demo-04
saturation |> summarise(observations = n(), succursales = n_distinct(succursale),
                        mois = n_distinct(mois))
tibble(ensemble = c("Apprentissage", "Validation"),
       n = c(nrow(apprentissage), nrow(validation)),
       minimum_visites = c(min(apprentissage$achalandage), min(validation$achalandage)),
       maximum_visites = c(max(apprentissage$achalandage), max(validation$achalandage)))


## -----------------------------------------------------------------------------
#| label: nuage-demo-04
#| fig-width: 9
#| fig-height: 5
ggplot(apprentissage, aes(achalandage, ventes)) +
  geom_point(aes(colour = succursale), alpha = 0.8, size = 2.4) +
  geom_smooth(method = "lm", se = FALSE, colour = "#7A1C24") +
  labs(x = "Achalandage mensuel (visites)", y = "Ventes mensuelles ($ CA)",
       colour = "Succursale") +
  theme_minimal(base_size = 13)


## -----------------------------------------------------------------------------
#| label: contexte-demo-04
#| fig-width: 9
#| fig-height: 5
ggplot(apprentissage, aes(taux_occupation, temps_attente_minutes)) +
  geom_point(aes(colour = succursale), size = 2.4) +
  geom_vline(xintercept = 1, linetype = "dashed") +
  scale_x_continuous(labels = scales::label_percent()) +
  labs(x = "Occupation de la capacité de référence", y = "Attente moyenne (minutes)",
       colour = "Succursale") +
  theme_minimal(base_size = 13)


## -----------------------------------------------------------------------------
#| label: modeles-demo-04
modele_lin <- lm(ventes ~ achalandage_milliers, data = apprentissage)
modele_quad <- lm(
  ventes ~ achalandage_milliers + I(achalandage_milliers^2),
  data = apprentissage
)
modele_log <- lm(ventes ~ log(achalandage_milliers), data = apprentissage)

modeles <- list("Linéaire" = modele_lin,
                "Quadratique" = modele_quad,
                "Logarithmique" = modele_log)


## -----------------------------------------------------------------------------
#| label: coefficients-demo-04
coef(modele_quad)
coef(modele_log)


## -----------------------------------------------------------------------------
#| label: interpretation-demo-04
scenarios <- tibble(achalandage_milliers = c(2, 2.1, 3, 3.1))
pred <- predict(modele_quad, newdata = scenarios)
tibble(comparaison = c("2 000 à 2 100 visites", "3 000 à 3 100 visites"),
       hausse_predite_dollars = c(pred[2] - pred[1], pred[4] - pred[3]))

# Modèle logarithmique : hausse de 10 % de l’achalandage.
unname(coef(modele_log)[2] * log(1.10))


## -----------------------------------------------------------------------------
#| label: comparaison-demo-04
rmse <- function(observe, predit) {
  stopifnot(length(observe) == length(predit),
            !anyNA(observe), !anyNA(predit))
  sqrt(mean((observe - predit)^2))
}

comparaison <- imap_dfr(modeles, function(ajustement, nom) {
  tibble(
    modele = nom,
    r2_apprentissage = summary(ajustement)$r.squared,
    r2_ajuste = summary(ajustement)$adj.r.squared,
    rmse_apprentissage = rmse(apprentissage$ventes, fitted(ajustement)),
    rmse_validation = rmse(validation$ventes,
                           predict(ajustement, newdata = validation))
  )
})
comparaison


## -----------------------------------------------------------------------------
#| label: courbes-demo-04
#| fig-width: 9
#| fig-height: 5
grille <- tibble(
  achalandage_milliers = seq(min(apprentissage$achalandage_milliers),
                             max(apprentissage$achalandage_milliers),
                             length.out = 120)
)
courbes <- imap_dfr(modeles, function(ajustement, nom) {
  grille |> mutate(modele = nom,
                   ventes_predites = predict(ajustement, newdata = grille))
})
ggplot(apprentissage, aes(achalandage_milliers, ventes)) +
  geom_point(alpha = 0.5) +
  geom_line(data = courbes, aes(y = ventes_predites, colour = modele),
            linewidth = 1.1) +
  labs(x = "Achalandage (milliers de visites)", y = "Ventes mensuelles ($ CA)",
       colour = "Modèle") +
  theme_minimal(base_size = 13)


## -----------------------------------------------------------------------------
#| label: residus-demo-04
#| fig-width: 9
#| fig-height: 5
diagnostic <- imap_dfr(modeles, function(ajustement, nom) {
  apprentissage |>
    mutate(modele = nom, ventes_predites = fitted(ajustement),
           residu = residuals(ajustement))
})
ggplot(diagnostic, aes(ventes_predites, residu)) +
  geom_hline(yintercept = 0, colour = "#7A1C24") +
  geom_point(aes(colour = succursale), alpha = 0.7) +
  facet_wrap(vars(modele)) +
  labs(x = "Ventes ajustées ($ CA)", y = "Résidu ($ CA)", colour = "Succursale") +
  theme_minimal(base_size = 12)

diagnostic |>
  group_by(modele, succursale) |>
  summarise(residu_moyen = mean(residu),
            erreur_absolue_moyenne = mean(abs(residu)), .groups = "drop")


## -----------------------------------------------------------------------------
#| label: prediction-demo-04
scenario <- tibble(achalandage_milliers = 2.5)
prediction <- predict(modele_quad, newdata = scenario,
                      interval = "prediction", level = 0.95)
prediction

# Nombre de lignes de validation hors de la plage d’apprentissage.
sum(validation$achalandage < min(apprentissage$achalandage) |
    validation$achalandage > max(apprentissage$achalandage))

# Illustration de l’extrapolation, sans validation à ce niveau.
imap_dfr(modeles, function(ajustement, nom) {
  tibble(modele = nom, visites = 6000,
         ventes_predites = predict(ajustement,
           newdata = tibble(achalandage_milliers = 6)))
})

