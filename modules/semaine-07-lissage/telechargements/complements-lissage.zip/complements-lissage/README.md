# Cahier facultatif du module 07

Décompressez tout, ouvrez le .Rproj et redémarrez R avant Render du .qmd.
Installez une fois tidyverse, slider et forecast si nécessaire. R, RStudio et Quarto sont requis.
Le script .R reprend tous les calculs. Aucun objet de console ou accès au dépôt n'est requis.
Ce cahier ne crée aucune production obligatoire. Le socle reste les quatre activités.
L'électricité est une simulation québécoise; 60 mois d'apprentissage puis 12 mois déjà connus.
Différences réintégrées, Holt-Winters, ETS, BATS, TBATS et STL sont des illustrations, sans gain garanti.
R/regenerer-donnees.R réécrit les deux CSV dans la copie courante, sans toucher au dépôt.
Attribution: cours MQT-2101, Université Laval. Données simulées redistribuables avec le cours.
Ancien script consulté: Paolo Landa (16 mars 2021). Aucun ancien document protégé n'est inclus.
