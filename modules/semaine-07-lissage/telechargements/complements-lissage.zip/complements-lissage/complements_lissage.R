## -----------------------------------------------------------------------------
#| label: preparation-complements-07
library(tidyverse)
library(slider)
library(forecast)
source("R/fonctions-module07.R")
electricite <- read_csv("data/consommation_electrique_batiment_quebec.csv", show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |> arrange(date)
stopifnot(nrow(electricite) == 72L, !anyNA(electricite), !anyDuplicated(electricite$date),
          identical(electricite$date, seq.Date(as.Date("2020-01-01"), by = "month", length.out = 72)))
apprentissage <- electricite |> slice_head(n = 60)
validation <- electricite |> slice_tail(n = 12)
serie <- ts(apprentissage$consommation_kwh, frequency = 12, start = c(2020, 1))
horizon <- 12L


## -----------------------------------------------------------------------------
#| label: differences-complements-07
#| fig-width: 9
#| fig-height: 6
difference_simple <- diff(serie)
difference_saison <- diff(serie, lag = 12)
difference_double <- diff(difference_saison)
par(mfrow = c(2, 2))
plot(serie, main = "Niveau", xlab = "Année", ylab = "kWh")
plot(difference_simple, main = "Différence à un mois", xlab = "Année", ylab = "Différence (kWh)")
plot(difference_saison, main = "Différence à douze mois", xlab = "Année", ylab = "Différence (kWh)")
plot(difference_double, main = "Deux différences", xlab = "Année", ylab = "Différence (kWh)")
par(mfrow = c(1, 1))
# Illustration de réintégration; ce SES des différences n’est pas un modèle retenu d’avance.
prevision_diff_simple <- as.numeric(ses(difference_simple, h = horizon)$mean)
prevision_niveau_simple <- tail(as.numeric(serie), 1) + cumsum(prevision_diff_simple)
# Pour h <= 12, le niveau de l’année précédente est encore dans l’apprentissage.
prevision_diff_saison <- as.numeric(ses(difference_saison, h = horizon)$mean)
prevision_niveau_saison <- tail(as.numeric(serie), 12) + prevision_diff_saison


## -----------------------------------------------------------------------------
#| label: ets-complements-07
prevision_ses <- ses(serie, h = horizon)
prevision_holt <- holt(serie, h = horizon, damped = TRUE)
prevision_hw_add <- hw(serie, h = horizon, seasonal = "additive")
prevision_hw_mult <- hw(serie, h = horizon, seasonal = "multiplicative")
modele_ets <- ets(serie)
prevision_ets <- forecast(modele_ets, h = horizon)
# ETS code erreur / tendance / saison; le critère utilisé est affiché explicitement.
modele_ets$method
tibble(AIC = modele_ets$aic, AICc = modele_ets$aicc, BIC = modele_ets$bic)


## -----------------------------------------------------------------------------
#| label: avance-complements-07
# Pas de parallélisme automatique: ces exemples restent bornés à la petite série.
modele_bats <- bats(serie, use.parallel = FALSE)
modele_tbats <- tbats(serie, use.parallel = FALSE)
modele_stl <- stlm(serie, s.window = "periodic", method = "ets")
prevision_bats <- forecast(modele_bats, h = horizon)
prevision_tbats <- forecast(modele_tbats, h = horizon)
prevision_stl <- forecast(modele_stl, h = horizon)


## -----------------------------------------------------------------------------
#| label: comparaison-complements-07
#| fig-width: 9
#| fig-height: 4.3
previsions <- list(
  Saisonnier_naif = as.numeric(snaive(serie, h = horizon)$mean),
  SES = as.numeric(prevision_ses$mean), Holt_amorti = as.numeric(prevision_holt$mean),
  Holt_Winters_additif = as.numeric(prevision_hw_add$mean),
  Holt_Winters_multiplicatif = as.numeric(prevision_hw_mult$mean),
  ETS_auto = as.numeric(prevision_ets$mean), BATS = as.numeric(prevision_bats$mean),
  TBATS = as.numeric(prevision_tbats$mean), STL_ETS = as.numeric(prevision_stl$mean),
  SES_diff_simple_reintegree = prevision_niveau_simple,
  SES_diff_saison_reintegree = prevision_niveau_saison
)
scores_complements <- imap_dfr(previsions, function(prevision, nom) {
  mesures_erreurs(validation$consommation_kwh, prevision) |> mutate(methode = nom)
}) |> select(methode, ME, MAE, RMSE) |> arrange(MAE)
scores_complements
courbes <- imap_dfr(previsions[c("Saisonnier_naif", "Holt_Winters_additif", "ETS_auto")],
                   ~ tibble(date = validation$date, prevision = .x, methode = .y))
ggplot() +
  geom_line(data = validation, aes(date, consommation_kwh / 1000), linewidth = 1) +
  geom_line(data = courbes, aes(date, prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Énergie mensuelle (MWh)", colour = "Méthode") +
  theme_minimal(base_size = 12)

