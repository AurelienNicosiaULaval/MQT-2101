# corrige-lissage-electricite

Version locale du 3 novembre 2026.
1. Décompressez toute l’archive et ouvrez le .Rproj.
2. Installez une fois tidyverse, slider et forecast si nécessaire. R, RStudio et Quarto sont requis.
3. Ouvrez le .qmd, redémarrez R, puis faites Render. Le projet de départ se rend avant d’être complété.
4. Les blocs visibles sont exécutables dans l’ordre. Le script .R reprend les calculs.
5. Conservez data/, R/ et media/ si présent. Les calculs ne nécessitent ni connexion au dépôt ni données distantes.

Deux séries fictives québécoises, sans mesure réelle. Les périodes de validation sont déjà connues du module 06.
Les coûts sont pédagogiques, sans tarif réel. Ce rapport est un entraînement, pas une remise évaluée.
Les compléments Holt et les pratiques supplémentaires sont facultatifs.
Pour reproduire les CSV dans une copie: source('R/regenerer-donnees.R'). Ce script réécrit les CSV locaux.
Les liens vers le cours et les ouvrages sont des compléments en ligne; cette version locale révisée peut précéder le site public.
Attribution: matériel du cours MQT-2101, Université Laval. Les données simulées sont redistribuables avec le cours.
Ancien matériel consulté: séance 07; script attribué à Paolo Landa (2021), sans redistribution des archives.
