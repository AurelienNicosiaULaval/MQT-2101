## -----------------------------------------------------------------------------
#| label: preparation-transfert-m07
library(tidyverse)
library(slider)
library(forecast)

# Ouvrir le projet .Rproj fourni : R/ et data/ sont à côté du rapport.
source("R/fonctions-module07.R")
electricite <- read_csv("data/consommation_electrique_batiment_quebec.csv",
                        show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |>
  arrange(date)
stopifnot(nrow(electricite) == 72L, !anyNA(electricite),
          !anyDuplicated(electricite$date),
          identical(electricite$date,
                    seq.Date(as.Date("2020-01-01"), by = "month", length.out = 72)))
horizon_e <- 12L
apprentissage_e <- electricite |> slice_head(n = 60)
validation_e <- electricite |> slice_tail(n = horizon_e)
serie_e <- ts(apprentissage_e$consommation_kwh, frequency = 12,
              start = c(2020, 1))


## -----------------------------------------------------------------------------
#| label: solution-fenetres-m07
#| fig-width: 9
#| fig-height: 4.3
electricite_lissee <- apprentissage_e |>
  mutate(mm3 = slide_dbl(consommation_kwh, mean, .before = 2, .complete = TRUE),
         mm12 = slide_dbl(consommation_kwh, mean, .before = 11, .complete = TRUE))
electricite_lissee |>
  select(date, consommation_kwh, mm3, mm12) |>
  pivot_longer(-date, names_to = "serie", values_to = "kwh") |>
  ggplot(aes(date, kwh / 1000, colour = serie)) +
  geom_line(na.rm = TRUE) +
  labs(x = NULL, y = "Énergie mensuelle (MWh)", colour = "Série") +
  theme_minimal(base_size = 12)
electricite_lissee |>
  filter(!is.na(mm12)) |>
  mutate(ecart_kwh = abs(mm3 - mm12)) |>
  filter(ecart_kwh > 20000) |>
  slice_head(n = 1) |>
  select(date, mm3, mm12, ecart_kwh)


## -----------------------------------------------------------------------------
#| label: solution-alpha-m07
niveaux_e <- apprentissage_e |>
  mutate(alpha_02 = niveau_ses(consommation_kwh, 0.2),
         alpha_08 = niveau_ses(consommation_kwh, 0.8))
niveaux_e |> select(date, consommation_kwh, alpha_02, alpha_08) |> tail(4)
previsions_e <- tibble(
  date = validation_e$date,
  observe = validation_e$consommation_kwh,
  Naive = rep(tail(apprentissage_e$consommation_kwh, 1), horizon_e),
  MM3 = rep(mean(tail(apprentissage_e$consommation_kwh, 3)), horizon_e),
  SES02 = rep(tail(niveaux_e$alpha_02, 1), horizon_e),
  SES08 = rep(tail(niveaux_e$alpha_08, 1), horizon_e),
  Saisonnier = as.numeric(snaive(serie_e, h = horizon_e)$mean)
)


## -----------------------------------------------------------------------------
#| label: solution-scores-m07
#| fig-width: 9
#| fig-height: 4.3
erreurs_e <- previsions_e |>
  pivot_longer(Naive:Saisonnier, names_to = "methode", values_to = "prevision") |>
  mutate(erreur = observe - prevision)
scores_e <- erreurs_e |>
  group_by(methode) |>
  group_modify(~ mesures_erreurs(.x$observe, .x$prevision,
                                cout_sous = 2, cout_sur = 1)) |>
  ungroup()
scores_e |> select(methode, ME, MAE, RMSE, cout_moyen) |> arrange(MAE)
ggplot() +
  geom_line(data = validation_e, aes(date, consommation_kwh / 1000),
            linewidth = 1) +
  geom_line(data = erreurs_e, aes(date, prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Énergie mensuelle (MWh)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: solution-decision-m07
scores_e |>
  select(methode, MAE, cout_moyen, sous_previsions) |>
  arrange(cout_moyen)
# Comparer les méthodes constantes, même si la référence saisonnière les bat.
scores_e |>
  filter(methode != "Saisonnier") |>
  select(methode, MAE, cout_moyen) |>
  arrange(cout_moyen)


## -----------------------------------------------------------------------------
#| label: pratique-5-m07
demandes_5 <- list(
  A = c(100, 100, 100, 160, 160, 160),
  B = c(100, 100, 100, 100, 100, 160)
)
references_5 <- function(y) {
  c(MM2 = mean(tail(y, 2)), MM4 = mean(tail(y, 4)),
    Naif = tail(y, 1))
}
resultats_5 <- as.data.frame(t(vapply(demandes_5, references_5, numeric(3))))
knitr::kable(resultats_5, col.names = c("MM2", "MM4", "Naïf"), caption = "Prévisions émises à la fin de la semaine 6, en unités")
knitr::kable(data.frame(
  Horizon = 1:3, A = rep(resultats_5["A", "MM4"], 3),
  B = rep(resultats_5["B", "MM4"], 3)
), caption = "Trois prévisions MM4 préparées ensemble, en unités")


## -----------------------------------------------------------------------------
#| label: pratique-6-m07
demandes_6 <- c(100, 110, 120, 130, 140, 150, 160)
cibles_6 <- 5:7
calcul_a_6 <- vapply(cibles_6, function(t) {
  mean(demandes_6[(t - 3):t])
}, numeric(1))
calcul_b_6 <- vapply(cibles_6, function(t) {
  mean(demandes_6[(t - 4):(t - 1)])
}, numeric(1))
calcul_c_6 <- rep(mean(demandes_6[1:4]), length(cibles_6))
comparaison_6 <- data.frame(
  Calcul = c("A : contient la cible", "B : origines successives", "C : origine 4"),
  Semaine_5 = c(calcul_a_6[1], calcul_b_6[1], calcul_c_6[1]),
  Semaine_6 = c(calcul_a_6[2], calcul_b_6[2], calcul_c_6[2]),
  Semaine_7 = c(calcul_a_6[3], calcul_b_6[3], calcul_c_6[3]),
  MAE = vapply(list(calcul_a_6, calcul_b_6, calcul_c_6), function(p) {
    mean(abs(demandes_6[cibles_6] - p))
  }, numeric(1))
)
knitr::kable(comparaison_6, row.names = FALSE,
             col.names = c("Calcul", "Semaine 5", "Semaine 6", "Semaine 7", "MAE (unités)"),
             caption = "Trois calculs, mais deux protocoles réalisables distincts")


## -----------------------------------------------------------------------------
#| label: pratique-7-m07
#| fig-width: 7.5
#| fig-height: 3.8
#| fig-alt: "Après une observation de 180 puis une de 120, les niveaux passent par 135 et 165 avant de se rejoindre à 131,25."
niveau_initial_7 <- 120
observations_7 <- c(180, 120)
calculer_niveaux_7 <- function(alpha) {
  niveaux <- c(niveau_initial_7, numeric(length(observations_7)))
  for (t in seq_along(observations_7)) {
    niveaux[t + 1] <- alpha * observations_7[t] + (1 - alpha) * niveaux[t]
  }
  niveaux
}
niveaux_7 <- cbind(calculer_niveaux_7(0.25), calculer_niveaux_7(0.75))
knitr::kable(data.frame(
  Etape = c("État initial", "Après la semaine 1", "Après la semaine 2"),
  `Alpha = 0,25` = niveaux_7[, 1],
  `Alpha = 0,75` = niveaux_7[, 2], check.names = FALSE
), digits = 2, format.args = list(decimal.mark = ","))
matplot(0:2, niveaux_7, type = "b", pch = c(16, 17), lty = c(1, 2),
        col = c("#075572", "#b40012"), ylim = c(115, 185), xaxt = "n",
        xlab = "Étape de mise à jour", ylab = "Niveau lissé (unités)")
axis(1, at = 0:2, labels = c("Initial", "Semaine 1", "Semaine 2"))
legend("topleft", legend = c("Alpha = 0,25", "Alpha = 0,75"),
       col = c("#075572", "#b40012"), pch = c(16, 17), lty = c(1, 2), bty = "n")


## -----------------------------------------------------------------------------
#| label: pratique-8-m07
observe_8 <- c(200, 220, 210, 240, 230, 260)
previsions_8 <- list(A = c(188, 208, 198, 228, 218, 248),
                    B = c(200, 220, 210, 240, 230, 188))
resumer_8 <- function(prevision) {
  erreur <- observe_8 - prevision
  c(MAE = mean(abs(erreur)), RMSE = sqrt(mean(erreur^2)),
    Semaines_urgentes = sum(erreur > 30))
}
resultats_8 <- as.data.frame(t(vapply(previsions_8, resumer_8, numeric(3))))
knitr::kable(resultats_8, digits = 2,
             col.names = c("MAE", "RMSE", "Semaines avec transport urgent"),
             format.args = list(decimal.mark = ","),
             caption = "Erreurs en unités; nombre de transports selon le scénario")


## -----------------------------------------------------------------------------
#| label: pratique-9-m07
#| fig-width: 8
#| fig-height: 4
#| fig-alt: "La série A garde quatre erreurs négatives puis quatre positives. La série B alterne les signes. Les deux moyennes sont nulles."
erreurs_9 <- list(A = c(rep(-2000, 4), rep(2000, 4)),
                  B = rep(c(-2000, 2000), 4))
mesurer_9 <- function(e) {
  c(ME = mean(e), MAE = mean(abs(e)), RMSE = sqrt(mean(e^2)))
}
mesures_kwh_9 <- t(vapply(erreurs_9, mesurer_9, numeric(3)))
knitr::kable(mesures_kwh_9, caption = "Mesures en kWh")
knitr::kable(mesures_kwh_9 / 1000, caption = "Les mêmes mesures en MWh")
parametres_9 <- par(mfrow = c(1, 2), mar = c(5.5, 4, 2, 1))
for (nom in names(erreurs_9)) {
  plot(1:8, erreurs_9[[nom]] / 1000, type = "b", pch = 16,
       col = "#075572", ylim = c(-3, 3), xaxt = "n",
       xlab = "Mois", ylab = "Erreur (MWh)", main = paste("Méthode", nom))
  axis(1, at = 1:8, labels = c("Janv.", "Févr.", "Mars", "Avr.", "Mai", "Juin", "Juill.", "Août"), las = 2, cex.axis = 0.85)
  abline(h = 0, lty = 2, col = "grey50")
}
par(parametres_9)


## -----------------------------------------------------------------------------
#| label: pratique-10-m07
observe_10 <- c(0, 100, 100, 100)
previsions_10 <- list(A = c(40, 98, 98, 98), B = c(0, 90, 90, 90))
echelle_10 <- 10
mesurer_10 <- function(prevision) {
  e <- observe_10 - prevision
  demande_positive <- observe_10 > 0
  c(MAE = mean(abs(e)), RMSE = sqrt(mean(e^2)),
    MAPE_complet = if (any(observe_10 == 0)) NA_real_ else
      100 * mean(abs(e / observe_10)),
    MAPE_semaines_positives = 100 * mean(abs(e[demande_positive] /
                                              observe_10[demande_positive])),
    MASE = mean(abs(e)) / echelle_10)
}
resultats_10 <- as.data.frame(t(vapply(previsions_10, mesurer_10, numeric(5))))
knitr::kable(resultats_10, digits = 2,
             col.names = c("MAE", "RMSE", "MAPE complet (%)", "MAPE des semaines positives (%)", "MASE"),
             format.args = list(decimal.mark = ","),
             caption = "MAE et RMSE en unités; MAPE en pourcentage; MASE sans unité")


## -----------------------------------------------------------------------------
#| label: pratique-11-m07
erreurs_11 <- list(A = rep(-10, 4), B = rep(8, 4))
cout_moyen_11 <- function(e, cout_sous, cout_sur) {
  mean(cout_sous * pmax(e, 0) + cout_sur * pmax(-e, 0))
}
resultats_11 <- data.frame(
  Methode = names(erreurs_11),
  MAE = vapply(erreurs_11, function(e) mean(abs(e)), numeric(1)),
  Sous_2_sur_1 = vapply(erreurs_11, cout_moyen_11, numeric(1),
                        cout_sous = 2, cout_sur = 1),
  Sous_1_sur_2 = vapply(erreurs_11, cout_moyen_11, numeric(1),
                        cout_sous = 1, cout_sur = 2)
)
knitr::kable(resultats_11, row.names = FALSE,
             col.names = c("Méthode", "MAE", "Sous : 2; sur : 1", "Sous : 1; sur : 2"),
             caption = "MAE en unités de produit et deux scénarios de coût moyen")


## -----------------------------------------------------------------------------
#| label: pratique-12-m07
comparaison_12 <- data.frame(
  Mesure = c("MAE", "RMSE"), Simple = c(100, 120), Nouvelle = c(99, 140)
)
comparaison_12$Variation_unites <- comparaison_12$Nouvelle - comparaison_12$Simple
comparaison_12$Variation_pourcent <- 100 * comparaison_12$Variation_unites /
  comparaison_12$Simple
knitr::kable(comparaison_12, digits = 2,
             col.names = c("Mesure", "Règle simple", "Nouvelle méthode", "Variation (unités)", "Variation (%)"),
             format.args = list(decimal.mark = ","),
             caption = "Variation = nouvelle méthode moins règle simple")


## -----------------------------------------------------------------------------
#| label: pratique-13-m07
modele_holt_e <- holt(serie_e, h = horizon_e, damped = TRUE)
modele_saisonnier_13 <- snaive(serie_e, h = horizon_e)
comparaison_holt_13 <- bind_rows(
  mesures_erreurs(validation_e$consommation_kwh,
                  as.numeric(modele_holt_e$mean), cout_sous = 2, cout_sur = 1) |>
    mutate(methode = "Holt amorti"),
  mesures_erreurs(validation_e$consommation_kwh,
                  as.numeric(modele_saisonnier_13$mean), cout_sous = 2, cout_sur = 1) |>
    mutate(methode = "Naïf saisonnier")
) |>
  select(methode, MAE, RMSE, cout_moyen)
knitr::kable(comparaison_holt_13, digits = 1,
             col.names = c("Méthode", "MAE (kWh)", "RMSE (kWh)", "Coût moyen"),
             format.args = list(decimal.mark = ",", big.mark = " "),
             caption = "Erreurs en kWh et coût pédagogique moyen par mois")

