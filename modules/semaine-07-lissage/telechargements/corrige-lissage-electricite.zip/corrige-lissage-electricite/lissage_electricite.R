## -----------------------------------------------------------------------------
#| label: preparation-transfert-m07
library(tidyverse)
library(slider)
library(forecast)

# Ouvrir le projet .Rproj fourni : R/ et data/ sont à côté du rapport.
source("R/fonctions-module07.R")
electricite <- read_csv("data/consommation_electrique_batiment_quebec.csv",
                        show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |>
  arrange(date)
stopifnot(nrow(electricite) == 72L, !anyNA(electricite),
          !anyDuplicated(electricite$date),
          identical(electricite$date,
                    seq.Date(as.Date("2020-01-01"), by = "month", length.out = 72)))
horizon_e <- 12L
apprentissage_e <- electricite |> slice_head(n = 60)
validation_e <- electricite |> slice_tail(n = horizon_e)
serie_e <- ts(apprentissage_e$consommation_kwh, frequency = 12,
              start = c(2020, 1))


## -----------------------------------------------------------------------------
#| label: solution-fenetres-m07
#| fig-width: 9
#| fig-height: 4.3
electricite_lissee <- apprentissage_e |>
  mutate(mm3 = slide_dbl(consommation_kwh, mean, .before = 2, .complete = TRUE),
         mm12 = slide_dbl(consommation_kwh, mean, .before = 11, .complete = TRUE))
electricite_lissee |>
  select(date, consommation_kwh, mm3, mm12) |>
  pivot_longer(-date, names_to = "serie", values_to = "kwh") |>
  ggplot(aes(date, kwh / 1000, colour = serie)) +
  geom_line(na.rm = TRUE) +
  labs(x = NULL, y = "Énergie mensuelle (MWh)", colour = "Série") +
  theme_minimal(base_size = 12)
electricite_lissee |>
  filter(!is.na(mm12)) |>
  mutate(ecart_kwh = abs(mm3 - mm12)) |>
  filter(ecart_kwh > 20000) |>
  slice_head(n = 1) |>
  select(date, mm3, mm12, ecart_kwh)


## -----------------------------------------------------------------------------
#| label: solution-alpha-m07
niveaux_e <- apprentissage_e |>
  mutate(alpha_02 = niveau_ses(consommation_kwh, 0.2),
         alpha_08 = niveau_ses(consommation_kwh, 0.8))
niveaux_e |> select(date, consommation_kwh, alpha_02, alpha_08) |> tail(4)
previsions_e <- tibble(
  date = validation_e$date,
  observe = validation_e$consommation_kwh,
  Naive = rep(tail(apprentissage_e$consommation_kwh, 1), horizon_e),
  MM3 = rep(mean(tail(apprentissage_e$consommation_kwh, 3)), horizon_e),
  SES02 = rep(tail(niveaux_e$alpha_02, 1), horizon_e),
  SES08 = rep(tail(niveaux_e$alpha_08, 1), horizon_e),
  Saisonnier = as.numeric(snaive(serie_e, h = horizon_e)$mean)
)


## -----------------------------------------------------------------------------
#| label: solution-scores-m07
#| fig-width: 9
#| fig-height: 4.3
erreurs_e <- previsions_e |>
  pivot_longer(Naive:Saisonnier, names_to = "methode", values_to = "prevision") |>
  mutate(erreur = observe - prevision)
scores_e <- erreurs_e |>
  group_by(methode) |>
  group_modify(~ mesures_erreurs(.x$observe, .x$prevision,
                                cout_sous = 2, cout_sur = 1)) |>
  ungroup()
scores_e |> select(methode, ME, MAE, RMSE, cout_moyen) |> arrange(MAE)
ggplot() +
  geom_line(data = validation_e, aes(date, consommation_kwh / 1000),
            linewidth = 1) +
  geom_line(data = erreurs_e, aes(date, prevision / 1000, colour = methode)) +
  labs(x = NULL, y = "Énergie mensuelle (MWh)", colour = "Méthode") +
  theme_minimal(base_size = 12)


## -----------------------------------------------------------------------------
#| label: solution-decision-m07
scores_e |>
  select(methode, MAE, cout_moyen, sous_previsions) |>
  arrange(cout_moyen)
# Comparer les méthodes constantes, même si la référence saisonnière les bat.
scores_e |>
  filter(methode != "Saisonnier") |>
  select(methode, MAE, cout_moyen) |>
  arrange(cout_moyen)


## -----------------------------------------------------------------------------
#| label: pratique-5-m07
y <- c(980, 1020, 1080, 1120)
c(MM4 = mean(y), naive = tail(y, 1), MM2 = mean(tail(y, 2)))


## -----------------------------------------------------------------------------
#| label: pratique-7-m07
mise_a_jour <- function(alpha) {
  l1 <- alpha * 140 + (1 - alpha) * 100
  l2 <- alpha * 140 + (1 - alpha) * l1
  c(l1 = l1, l2 = l2)
}
rbind(alpha02 = mise_a_jour(0.2), alpha08 = mise_a_jour(0.8))


## -----------------------------------------------------------------------------
#| label: pratique-8-m07
erreurs_a <- c(10, 10, 10, 10)
erreurs_b <- c(0, 0, 0, 40)
calcul <- function(e) c(MAE = mean(abs(e)), RMSE = sqrt(mean(e^2)))
rbind(A = calcul(erreurs_a), B = calcul(erreurs_b))


## -----------------------------------------------------------------------------
#| label: pratique-9-m07
e <- c(-20, 0, 20)
c(ME_kwh = mean(e), MAE_kwh = mean(abs(e)),
  ME_mwh = mean(e / 1000), MAE_mwh = mean(abs(e / 1000)))


## -----------------------------------------------------------------------------
#| label: pratique-10-m07
observe <- c(0, 20)
predit <- c(5, 15)
e <- observe - predit
c(MAE = mean(abs(e)), RMSE = sqrt(mean(e^2)),
  MAPE = if (any(observe == 0)) NA_real_ else 100 * mean(abs(e / observe)))


## -----------------------------------------------------------------------------
#| label: pratique-11-m07
perte <- function(e) c(MAE = mean(abs(e)),
  cout = mean(2 * pmax(e, 0) + pmax(-e, 0)))
rbind(A = perte(c(-10, -10)), B = perte(c(8, 8)))


## -----------------------------------------------------------------------------
#| label: pratique-13-m07
modele_holt_e <- holt(serie_e, h = horizon_e, damped = TRUE)
mesures_erreurs(validation_e$consommation_kwh,
                as.numeric(modele_holt_e$mean), 2, 1)
scores_e |> filter(methode == "Saisonnier")

