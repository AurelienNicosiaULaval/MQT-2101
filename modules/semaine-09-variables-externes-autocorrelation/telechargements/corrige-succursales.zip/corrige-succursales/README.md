# Projet du module 09

Décompressez toute l’archive et ouvrez le fichier .Rproj. Installez tidyverse et forecast, puis rendez le .qmd dans une session neuve. Les données sont simulées; consultez data/dictionnaires.md. Le script R/regenerer-donnees.R réécrit les deux CSV locaux. Les scores sur 2025 et les scénarios sont conditionnels aux informations indiquées. Matériel MQT-2101, Université Laval.
