library(tidyverse)
racines <- c(".", "modules/semaine-09-variables-externes-autocorrelation")
racine <- racines[file.exists(file.path(racines, "data/cas_integrateur_quebec.csv"))][1]
stopifnot(!is.na(racine))
service <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date), succursale = factor(succursale),
         promotion = factor(promotion, levels = c("non", "oui"))) |>
  arrange(succursale, date) |>
  group_by(succursale) |>
  mutate(ventes_retard_1 = lag(ventes)) |>
  ungroup()
stopifnot(nrow(service) == 288, !anyDuplicated(service[c("succursale", "date")]))
entrainement_service <- service |> filter(date < as.Date("2025-01-01"))


modele_base <- lm(ventes ~ indice_temps + promotion + succursale, data = entrainement_service)
diagnostic <- entrainement_service |>
  mutate(residu = residuals(modele_base)) |>
  arrange(succursale, date) |>
  group_by(succursale) |>
  summarise(autocorrelation_rang_1 = cor(residu, lag(residu), use = "complete.obs"), .groups = "drop")
diagnostic


# Un mois à partir de fin 2025 : le dernier mois et son chiffre de ventes sont disponibles.
modele_scenario <- lm(ventes ~ indice_temps + promotion + capacite + ventes_retard_1,
                      data = service |> filter(!is.na(ventes_retard_1)))
profil <- service |> filter(succursale == "Québec") |> slice_max(date, n = 1, with_ties = FALSE) |>
  transmute(indice_temps = indice_temps + 1, promotion = factor("non", levels = levels(service$promotion)),
            capacite, ventes_retard_1 = ventes)
scenarios <- bind_rows(profil |> mutate(scenario = "Capacité inchangée"),
                       profil |> mutate(capacite = capacite * 1.05, scenario = "Capacité augmentée de 5 %")) |>
  mutate(prevision = as.numeric(predict(modele_scenario, newdata = pick(everything()))))
scenarios
