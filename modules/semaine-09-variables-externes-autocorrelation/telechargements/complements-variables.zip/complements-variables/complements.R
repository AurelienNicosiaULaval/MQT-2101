library(tidyverse)
library(forecast)

racines <- c(".", "modules/semaine-09-variables-externes-autocorrelation")
racine <- racines[file.exists(file.path(racines, "data/ventes_promotions_quebec.csv"))][1]
stopifnot(!is.na(racine))
ventes <- read_csv(file.path(racine, "data/ventes_promotions_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date), promotion = factor(promotion, levels = c("non", "oui")),
         mois = factor(mois, levels = 1:12)) |>
  arrange(date)
stopifnot(nrow(ventes) == 72, !anyDuplicated(ventes$date),
          all(!is.na(ventes)), all(ventes$date == seq.Date(as.Date("2020-01-01"), by = "month", length.out = 72)))
entrainement <- ventes |> slice_head(n = 60)
validation <- ventes |> slice_tail(n = 12)


ventes |> transmute(date, ventes, retard_1 = lag(ventes), retard_12 = lag(ventes, 12)) |> slice_head(n = 14)
acf(entrainement$ventes, lag.max = 24, main = "ACF des ventes brutes")


modele_lm <- lm(ventes ~ tendance + promotion + prix_moyen + indice_confiance + mois,
                data = entrainement)
coef(summary(modele_lm))[c("tendance", "promotionoui", "prix_moyen", "indice_confiance"), ]


ar_residus <- Arima(residuals(modele_lm), order = c(1, 0, 0))
futur_residu <- forecast(ar_residus, h = 12)
prevision_deux_etapes <- as.numeric(predict(modele_lm, newdata = validation)) + as.numeric(futur_residu$mean)
tibble(date = validation$date, observe = validation$ventes, prevision_deux_etapes) |>
  summarise(MAE = mean(abs(observe - prevision_deux_etapes)), RMSE = sqrt(mean((observe - prevision_deux_etapes)^2)))


modele_interaction <- lm(ventes ~ tendance + mois + promotion * prix_moyen + indice_confiance,
                         data = entrainement)
coef(modele_interaction)[c("promotionoui", "prix_moyen", "promotionoui:prix_moyen")]
model.matrix(~ promotion * prix_moyen, data = entrainement) |> head()


serie <- ts(entrainement$ventes, start = c(2020, 1), frequency = 12)
modele_ar <- Arima(serie, order = c(1, 0, 0))
modele_ari <- Arima(serie, order = c(1, 1, 0))
modele_arima <- Arima(serie, order = c(1, 1, 1))
# Illustrations sur les mêmes 12 mois; pas de sélection automatique.
tibble(modele = c("AR(1)", "ARI(1,1)", "ARIMA(1,1,1)"),
       MAE = c(mean(abs(validation$ventes - forecast(modele_ar, h = 12)$mean)),
               mean(abs(validation$ventes - forecast(modele_ari, h = 12)$mean)),
               mean(abs(validation$ventes - forecast(modele_arima, h = 12)$mean))))
