# Corrigés des productions sur l’électricité

1. Décompressez toute l’archive.
2. Ouvrez le fichier .Rproj, puis le document .qmd.
3. Installez une fois tidyverse et forecast si nécessaire. R, RStudio et Quarto sont requis.
4. Exécutez le code dans l’ordre ou utilisez Render. Le script .R reprend les calculs.
5. Redémarrez R avant le rendu final. Conservez les dossiers R/ et data/.

Les données sont simulées pour l’enseignement. Ce projet est un entraînement, pas une remise évaluée.
Les deux compléments et les exercices de consolidation sont facultatifs.
Les calculs utilisent uniquement les fichiers fournis; les liens bibliographiques sont des lectures complémentaires en ligne.
