## -----------------------------------------------------------------------------
#| label: preparation-corriges-electricite-06
library(tidyverse)
library(forecast)

# Dans le projet téléchargé, les dossiers R/ et data/ sont à côté du document.
chemins_fonctions_capsules <- c(
  "R/analyse-module06.R",
  "modules/semaine-06-series-chronologiques-intro/R/analyse-module06.R"
)
chemin_fonctions_capsules <- chemins_fonctions_capsules[
  file.exists(chemins_fonctions_capsules)
][1]
stopifnot(!is.na(chemin_fonctions_capsules))
source(chemin_fonctions_capsules)

chemins_csv_capsules <- c(
  "data/consommation_electrique_batiment_quebec.csv",
  "modules/semaine-06-series-chronologiques-intro/data/consommation_electrique_batiment_quebec.csv"
)
chemin_csv_capsules <- chemins_csv_capsules[file.exists(chemins_csv_capsules)][1]
stopifnot(!is.na(chemin_csv_capsules))
electricite_capsules <- read_csv(chemin_csv_capsules, show_col_types = FALSE) |>
  mutate(date = as.Date(date)) |>
  arrange(date)
apprentissage_capsules <- electricite_capsules |>
  filter(date < as.Date("2025-01-01"))
validation_capsules <- electricite_capsules |>
  filter(date >= as.Date("2025-01-01"))


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-2
#| fig-width: 8
#| fig-height: 4.5
ggplot(apprentissage_capsules, aes(date, consommation_kwh / 1000)) +
  geom_line(colour = "#0B4F6C") +
  geom_point() +
  labs(x = NULL, y = "Consommation mensuelle (MWh)") +
  theme_minimal()

ggplot(apprentissage_capsules,
       aes(mois, consommation_kwh / 1000, group = annee,
           colour = factor(annee))) +
  geom_line() +
  geom_point() +
  scale_x_continuous(breaks = 1:12) +
  labs(x = "Mois", y = "Consommation mensuelle (MWh)", colour = "Année") +
  theme_minimal()

tibble(niveau_kwh = c(200000, 400000)) |>
  mutate(
    apres_hausse_fixe_kwh = niveau_kwh + 20000,
    hausse_fixe_pourcent = 100 * 20000 / niveau_kwh,
    apres_hausse_10_pourcent_kwh = niveau_kwh * 1.10,
    hausse_10_pourcent_kwh = niveau_kwh * 0.10
  ) |>
  knitr::kable(digits = 0)


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-3
apprentissage_capsules |>
  summarise(
    debut = min(date), fin = max(date), mois_presents = n(),
    dates_dupliquees = sum(duplicated(date)),
    dates_manquantes = sum(is.na(date)),
    consommations_manquantes = sum(is.na(consommation_kwh))
  )

grille_capsules <- tibble(
  date = seq.Date(as.Date("2020-01-01"), as.Date("2024-12-01"), by = "month")
)
grille_capsules |> anti_join(apprentissage_capsules, by = "date")


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-4
#| fig-width: 8
#| fig-height: 4.5
previsions_capsules <- validation_capsules |>
  mutate(
    h = row_number(),
    naive = rep(tail(apprentissage_capsules$consommation_kwh, 1), n()),
    saisonniere = tail(apprentissage_capsules$consommation_kwh, 12)
  )
previsions_capsules |>
  select(date, h, naive, saisonniere, consommation_kwh) |>
  knitr::kable()

previsions_capsules |>
  pivot_longer(c(naive, saisonniere),
               names_to = "methode", values_to = "prevision") |>
  ggplot(aes(date, prevision / 1000, colour = methode)) +
  geom_line() +
  geom_line(data = validation_capsules,
            aes(date, consommation_kwh / 1000),
            inherit.aes = FALSE, colour = "black") +
  labs(x = NULL, y = "Consommation (MWh)", colour = "Référence",
       subtitle = "Noir : observations de 2025; origine fin décembre 2024") +
  theme_minimal()


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-5
#| fig-width: 8
#| fig-height: 4.5
serie_capsules <- ts(apprentissage_capsules$consommation_kwh,
                     start = c(2020, 1), frequency = 12)
tendance_capsules <- tslm(serie_capsules ~ trend + I(trend^2))
previsions_capsules <- previsions_capsules |>
  mutate(tendance = as.numeric(forecast(tendance_capsules, h = 12)$mean))
evaluation_capsules <- previsions_capsules |>
  pivot_longer(c(naive, saisonniere, tendance),
               names_to = "methode", values_to = "prevision") |>
  mutate(erreur = consommation_kwh - prevision)
scores_capsules <- evaluation_capsules |>
  group_by(methode) |>
  group_modify(~ mesures_erreur(
    .x$consommation_kwh, .x$prevision,
    apprentissage_capsules$consommation_kwh, periode = 12
  )) |>
  ungroup()
scores_capsules |>
  knitr::kable(digits = 2,
    col.names = c("Méthode", "ME (kWh)", "MAE (kWh)", "RMSE (kWh)",
                  "MAPE (%)", "MASE"),
    format.args = list(decimal.mark = ",", big.mark = " "))

erreurs_saisonnieres_capsules <- evaluation_capsules |>
  filter(methode == "saisonniere")
ggplot(erreurs_saisonnieres_capsules, aes(date, erreur / 1000)) +
  geom_hline(yintercept = 0, linetype = 2) +
  geom_line() + geom_point() +
  labs(x = NULL, y = "Erreur de prévision (MWh)") + theme_minimal()
ggplot(erreurs_saisonnieres_capsules, aes(erreur / 1000)) +
  geom_histogram(bins = 6, fill = "#D9EEF2", colour = "#0B4F6C") +
  labs(x = "Erreur de prévision (MWh)", y = "Nombre de mois") + theme_minimal()


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-6
#| fig-width: 8
#| fig-height: 4.5
modele_intervalle_capsules <- ets(serie_capsules, model = "AAN")
cone_capsules <- forecast(modele_intervalle_capsules,
                          h = 12, level = c(80, 95))
autoplot(cone_capsules) +
  labs(x = "Année", y = "Consommation (kWh)",
       title = "ETS(A,A,N), origine fin décembre 2024") + theme_minimal()
tibble(
  mois = c("Janvier 2025", "Décembre 2025"), h = c(1, 12),
  point_kwh = as.numeric(cone_capsules$mean[c(1, 12)]),
  bas_80 = cone_capsules$lower[c(1, 12), "80%"],
  haut_80 = cone_capsules$upper[c(1, 12), "80%"],
  bas_95 = cone_capsules$lower[c(1, 12), "95%"],
  haut_95 = cone_capsules$upper[c(1, 12), "95%"]
) |>
  knitr::kable(digits = 0,
    format.args = list(decimal.mark = ",", big.mark = " "))


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-7
mobile_capsules <- validation_mobile(
  electricite_capsules$consommation_kwh,
  debut_validation = 61, horizons = c(1L, 6L), periode = 12
) |>
  mutate(
    mois_origine = electricite_capsules$date[origine],
    mois_cible = electricite_capsules$date[cible]
  )
mobile_capsules |>
  group_by(h, methode) |>
  summarise(
    origines = n(),
    premier_mois_origine = min(mois_origine),
    dernier_mois_origine = max(mois_origine),
    derniere_cible = max(mois_cible),
    MAE_kwh = mean(abs(erreur)), .groups = "drop"
  ) |>
  knitr::kable(digits = 2)


## -----------------------------------------------------------------------------
#| label: corrige-capsule-06-8
combinaison_capsules <- previsions_capsules |>
  mutate(combinee = (naive + saisonniere) / 2)
combinaison_capsules |>
  pivot_longer(c(naive, saisonniere, combinee),
               names_to = "methode", values_to = "prevision") |>
  group_by(methode) |>
  summarise(MAE_kwh = mean(abs(consommation_kwh - prevision)),
            .groups = "drop") |>
  knitr::kable(digits = 2)

