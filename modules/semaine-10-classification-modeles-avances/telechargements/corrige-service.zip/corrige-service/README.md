# Projet du module 10

Décompressez toute l’archive et ouvrez le fichier .Rproj. Installez tidyverse, puis rendez le .qmd dans une session R neuve. Le complément facultatif utilise aussi rpart. Les données sont fictives : consultez data/dictionnaires.md. Le script R/regenerer-donnees.R réécrit les deux CSV locaux. Matériel MQT-2101, Université Laval.
