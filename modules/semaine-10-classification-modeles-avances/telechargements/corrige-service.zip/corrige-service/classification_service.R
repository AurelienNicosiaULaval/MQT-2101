library(tidyverse)
racines <- c(".", "modules/semaine-10-classification-modeles-avances")
racine <- racines[file.exists(file.path(racines, "data/cas_integrateur_quebec.csv"))][1]
stopifnot(!is.na(racine))
service <- read_csv(file.path(racine, "data/cas_integrateur_quebec.csv"), show_col_types = FALSE) |>
  mutate(date = as.Date(date), succursale = factor(succursale),
         cible = service_insuffisant_mois_suivant) |> arrange(date, succursale)
stopifnot(nrow(service) == 288, !anyDuplicated(service[c("date", "succursale")]),
          all(service$cible %in% c(0, 1)))
apprentissage_service <- service |> filter(date <= as.Date("2023-11-01"))
validation_service <- service |> filter(date >= as.Date("2024-01-01"), date <= as.Date("2024-11-01"))
test_service <- service |> filter(date >= as.Date("2025-01-01"))


mesures_seuil <- function(observe, probabilite, seuil, cout_fp = 1, cout_fn = 4) {
  stopifnot(length(observe) == length(probabilite), all(observe %in% c(0, 1)),
            all(is.finite(probabilite)), all(probabilite >= 0 & probabilite <= 1))
  predit <- as.integer(probabilite >= seuil)
  vp <- sum(predit == 1 & observe == 1); fp <- sum(predit == 1 & observe == 0)
  vn <- sum(predit == 0 & observe == 0); fn <- sum(predit == 0 & observe == 1)
  ratio <- function(a, b) if (b == 0) NA_real_ else a / b
  tibble(seuil, VP = vp, FP = fp, VN = vn, FN = fn,
         exactitude = ratio(vp + vn, length(observe)), sensibilite = ratio(vp, vp + fn),
         specificite = ratio(vn, vn + fp), precision = ratio(vp, vp + fp),
         proportion_ciblee = ratio(vp + fp, length(observe)), cout = cout_fp * fp + cout_fn * fn)
}


modele_service <- glm(cible ~ taux_utilisation + ruptures_stock + temps_attente + satisfaction,
                      data = apprentissage_service, family = binomial())
stopifnot(modele_service$converged, all(is.finite(coef(modele_service))))
profils_service <- tibble(taux_utilisation = c(0.90, 0.90), ruptures_stock = c(0, 5),
                          temps_attente = c(5, 5), satisfaction = c(7, 7))
profils_service |> mutate(probabilite = predict(modele_service, newdata = profils_service, type = "response"))


validation_service <- validation_service |>
  mutate(probabilite = predict(modele_service, newdata = validation_service, type = "response"))
comparaison_service <- bind_rows(mesures_seuil(validation_service$cible, validation_service$probabilite, 0.25),
                                mesures_seuil(validation_service$cible, validation_service$probabilite, 0.50))
comparaison_service |> select(seuil, VP, FP, VN, FN, cout)
comparaison_service |> select(seuil, sensibilite, specificite, precision, proportion_ciblee)
seuil_service <- comparaison_service |> arrange(cout, seuil) |> slice(1) |> pull(seuil)
seuil_service


test_service <- test_service |> mutate(probabilite = predict(modele_service, newdata = test_service, type = "response"))
resultat_service <- mesures_seuil(test_service$cible, test_service$probabilite, seuil_service)
resultat_service |> select(seuil, VP, FP, VN, FN, cout)
resultat_service |> select(seuil, sensibilite, specificite, precision, proportion_ciblee)
# Règle fixée à l’avance : deux interventions au plus par mois.
selection_service <- test_service |> group_by(date) |>
  arrange(desc(probabilite), succursale, .by_group = TRUE) |> slice_head(n = 2) |> ungroup()
selection_service |> count(succursale, name = "mois_cibles")
selection_service |> summarise(cibles = n(), positifs_detectes = sum(cible), precision = mean(cible))
